package com.utility;

import java.util.List;
import java.util.Map;

public class Bazaar {

 private Map<Integer,String> policyMap;

 public Map<Integer, String> getPolicyMap() {
 return policyMap;
 }

 public void setPolicyMap(Map<Integer, String> policyMap) {
 this.policyMap = policyMap;
}

 //This method should add the policyID as key and policyName as value into the policyMap
 public void addPolicyDetails(int policyId,String policyName)
 {

 }

/*
25 * This method should search the policy name based on the policy type and add those polic
26 * into the list and return the list.
27 * For example: If the map contains the key and value as:
28 * 10654 Max Bupa Health Insurance
29 10321 SBI Health Insurance
30 20145 IFFCO Tokio Two Wheeler Insurance
31 20165 New India Assurance Two Wheeler Insurance
32 10110 Reliance Health Insurance
33 if the policy type is Health the output should be
34 10110
35 10321
36 10654
37
38 */
 public List<Integer> searchBasedOnPolicyType(String policyType){
	  return null;

 }


 }
