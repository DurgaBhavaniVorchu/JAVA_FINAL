package com.ui;
import com.utility.*;
import java.util.*;

 public class UserInterface {

 public static void main(String[] args) {

Scanner sc =new Scanner(System.in);



 }

 }