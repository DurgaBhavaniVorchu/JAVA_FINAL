package service;

public interface Medical 
{
	public void storeInService();
}
