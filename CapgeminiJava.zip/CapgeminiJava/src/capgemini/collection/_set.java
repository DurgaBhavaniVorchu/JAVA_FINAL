package capgemini.collection;

import java.util.HashSet;
import java.util.Iterator;

public class _set {
	public static void main(String args[]){
		HashSet<String> hashSet = new HashSet<String>();
		System.out.println("Size:"+hashSet.size()+"\t"+hashSet);
		hashSet.add("JAN");
		hashSet.add("JAN");
		hashSet.add(null);
		hashSet.add(null);
		hashSet.add("FEB");
		hashSet.add("MAR");
		System.out.println("Size:"+hashSet.size()+"\t"+hashSet);
		
		hashSet.remove("MAR");
		System.out.println("Size:"+hashSet.size()+"\t"+hashSet);
		
		Iterator<String> iterator = hashSet.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
		//enhanced forloop
		for (String Value:hashSet){
			System.out.println(Value);
		}
	}
}
