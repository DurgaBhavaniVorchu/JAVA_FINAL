package capgemini.collection;


import java.util.*;
public class _List{
	
	static void main(String[] args) {
		//ArrayList<String> list = new ArrayList<String>(3);
		//LinkedList<String> list = new LinkedList<String>();
		Vector<String> list = new Vector<String>();
		
		list.add("Sun");
		list.add("Mon");
		list.add("Wed");
		System.out.println("Size:"+list.size()+"\t"+list);
		
		  
		//added based on index
		list.add(2,"Tue");
		System.out.println("Size:"+list.size()+"\t"+list);
		
		list.add("Thus");
		list.add("Free");
		list.add("Sat");
		list.add("Soon");
		System.out.println("Size:"+list.size()+"\t"+list);
		
		int index=list.indexOf("Free");
		if(index != -1)
			list.set(indexOf("Free"),  "Fri"); 
		
		//searched a string
		if(list.contains("Free"))
			list.set(5,  "Fri");      //modified a value....
		System.out.println("Size:"+list.size()+"\t"+list);
		
		if(list.contains("Soon"))
			list.remove("Soon");      //modified a value....
		System.out.println("Size:"+list.size()+"\t"+list);
		
		//iterating........
		for(String Value:list){
			System.out.println(Value);
		}
		
	}
	
}