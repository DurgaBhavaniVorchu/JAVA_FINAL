package capgemini.collection;

import java.util.HashMap;
import java.util.Iterator;

public class _HashMap {
	public static void main(String args[]){
		HashMap<Integer, String> hashMap = new HashMap<Integer, String>();
		System.out.println("Size:"+hashMap.size()+"\t"+hashMap);
		hashMap.put(null,  null);
		hashMap.put(null,  null);
		hashMap.put(0,  null);
		hashMap.put(1,  "Mon");
		hashMap.put(1,  "Jan");
		hashMap.put(2,  "Feb");
		hashMap.put(3,  "Mar");
		System.out.println("Size:"+hashMap.size()+"\t"+hashMap);
		
		//hashMap.iterate(); do not get iterate directly.....
		Iterator<Integer> itrKeys = hashMap.keySet().iterator();    // itertor
		System.out.println("printing value.....");
		while(itrKeys.hasNext()) {
			System.out.println(itrKeys.next());
		}
		
		Iterator<String> itrValues = hashMap.values().iterator();
		System.out.println("Printing Values....");
		while(itrValues.hasNext()) {
			System.out.println(itrValues.next());
		}
		
		Iterator<Integer> itrKeys2 = hashMap.keySet().iterator();
		System.out.println("Printing Values....");
		while(itrKeys2.hasNext()) {
			System.out.println(itrKeys2.next());
		}
	}
}
