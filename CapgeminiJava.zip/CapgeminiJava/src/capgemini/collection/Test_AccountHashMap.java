package capgemini.collection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import capgemini.banking.bean.Account;

public class Test_AccountHashMap {
	public static void main(String[] args) {
		HashMap<Long, Account> map_Account = new HashMap<Long, Account>();

		// creating account..
		long accountNo1 = 8639, accountNo2 = 86398, accountNo3 = 863958;

		Account account1 = new Account(accountNo1, "Savings", 5000);
		Account account2 = new Account(accountNo2, "Bussiness", 10000);
		Account account3 = new Account(accountNo3, "Current", 15000);

		map_Account.put(account1.getAccount_number(), account1);
		map_Account.put(account2.getAccount_number(), account2);
		map_Account.put(account3.getAccount_number(), account3);

		// printing account to map
		//System.out.println(map_Account);
		
		// Account - Alien depositing 2000
		Set<Long> keySet = map_Account.keySet();
		Iterator<Long> iterator = keySet.iterator();
		while (iterator.hasNext()) {
			long acc = iterator.next();
			if (acc == accountNo1) {					
				System.out.println(accountNo1 + " found...");
			}
			if (acc == accountNo2) {
				System.out.println(accountNo2 + " found...");
			}
			if (acc == accountNo3) {
				System.out.println(accountNo3 + " found...");
			}
			//System.out.println();
		}
		System.out.println("iterator completed...");

		System.out.println("Account1:" + map_Account.containsKey(accountNo1));	// failing....
		System.out.println("Account2:" + map_Account.containsKey(accountNo2));
		System.out.println("Account3:" + map_Account.containsKey(accountNo3));

		if (map_Account.containsKey(accountNo1)) {
			Account accountSavings = map_Account.get(accountNo1);
			double currentBalance = accountSavings.getCurrentBalance();
			currentBalance += 2000; // deposit 2000 and update the balance
			accountSavings.setCurrentBalance(currentBalance);
			System.out.println("Savings Account: " + accountSavings);
		}

		// map_Account.values().forEach((account) ->
		// System.out.println(account));

		// Funds Transfer - chappel-103 to Boston-102 ->transfer 1000
		Account accountBusiness = null, accountCurrent = null;

		if (map_Account.containsKey(accountNo2)) {
			accountBusiness = map_Account.get(accountNo2);
		}
		if (map_Account.containsKey(accountNo3)) {
			accountCurrent = map_Account.get(accountNo3);
		}

		double currentBalanceBusiness = accountBusiness.getCurrentBalance();
		double currentBalanceCurrent = accountCurrent.getCurrentBalance();

		currentBalanceBusiness += 1000;
		currentBalanceCurrent -= 1000;

		// update balance - Business
		accountBusiness.setCurrentBalance(currentBalanceBusiness);

		// update balance - current
		accountCurrent.setCurrentBalance(currentBalanceCurrent);

		// printing all accounts from map
		map_Account.values().forEach(System.out::println);
	}
}
