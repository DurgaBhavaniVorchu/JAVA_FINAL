package capgemini.collection;

import java.util.Arrays;

public class Test_Collection {
	public static void main(String args[]){
		int[] nums = {1, 2, 3, 4, 5};
		for(int i =0 ; i<nums.length ; i++)
			System.out.println(nums[i]);
		System.out.println("Natural order : "+Arrays.toString(nums));
		
		// enhanced for loop......not indexed based.........
		for(int num:nums)
			System.out.println(nums);
		
		//algorithems for arrays.........
		Arrays.sort(nums);
		System.out.println("Sorted Order:"+Arrays.toString(nums));
		
		//char arrays.....
		char[] alpha = {'A', 'B', 'C', 'D', 'E'};
		System.out.println("Natural order:"+Arrays.toString(alpha));
		
		Arrays.sort(alpha);
		System.out.println("Sorted Order:"+Arrays.toString(alpha));
		
		String[] days = {"Mon", "Tue", "wed", "Thu", "Fri", "Sat", "Sun"};
		System.out.println("Natural order:"+Arrays.toString(days));
		
		Arrays.sort(days);
		System.out.println("Sorted order:"+Arrays.toString(days));
	}
}
