package capgemini.collection;

public class Test_BoxUnBox {
	public static void main(String args[]){
		int _int = 10;
		Integer _ObjInt = new Integer(10);
		
		_int = _ObjInt;             //object type is converted to primitive type
		_ObjInt = _int;             // primitive type is converted to object type
		
		//before JDK 1.5 -explicit type conversion was done
		//object type is converted and assigned to primitive type
		_int = _ObjInt.intValue();
		
		//object type is converted and assigned to primitive type
		_ObjInt = Integer.valueOf(_int);
	}
}
