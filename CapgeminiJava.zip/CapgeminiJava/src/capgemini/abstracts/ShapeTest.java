package capgemini.abstracts;

import capgemini.oops.Circle_Test;

abstract class Shape {
	public Shape() {
		super();	// will call default constructor of Object class...
		System.out.println("shape->def..........");
	}
	
	public void draw() {
		System.out.println("shape is draw....");
	}
	
	public abstract double calcArea();
	
	@Override
	public String toString() {
		return "shape:->";
	}
	
	public void showCircle(){
		System.out.println("I am in Circle............");
	}
}
class Circle extends Shape {
	//fields..
	float radius;
	
	//def const.....
	public Circle(){
		super();
		System.out.println("circle->def...");
	}
	
	//paras const......
	public Circle(float radius) {
		super();
		this.radius = radius;
	}
	
	@Override
	public void draw(){
		super.draw();
		System.out.println("circle is draw.......");
	}
	@Override
	public double calcArea() {
		return radius*radius*Math.PI;
	}
	
	//toString...
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if(obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Circle other = (Circle)obj;
		if(Float.floatToIntBits(radius) != Float.floatToIntBits(other.radius))
			return false;
		return true;
	}
}

public class ShapeTest {
	
	public static void main(String arg[]) {
		//Shape shape;
		//shape = new shape(
		// shape can not be initiallized, it is abstract
		Circle c1 = new Circle();
		c1.draw();
		c1.calcArea();
		
		c1.showCircle();
		
		Shape shape = new Circle();
		shape.draw();
		shape.calcArea();
		
		shape.showCircle();
	}

}
