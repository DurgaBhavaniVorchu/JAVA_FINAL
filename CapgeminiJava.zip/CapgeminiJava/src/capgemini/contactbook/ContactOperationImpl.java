package capgemini.contactbook;

import java.io.*;
import java.util.*;

public class ContactOperationImpl implements ContactOperation{
	Contact[] contacts;
	public ContactOperationImpl(int size){
		super();
		contacts = new Contact[size];
	}
	
	@Override
	public void addContact(Contact Contact){
		
		for(int i=0;i<contacts.length;i++){
			if(contacts[i]==null){
				contacts[i] = Contact;
				break;
			}
		}
	}

	@Override
	public void deleteContact(String firstName) {
		for(int i=0;i<contacts.length;i++){
			if(contacts[i] != null && contacts[i].getFirstName().equals(firstName)){
				contacts[i] = null;
				break;
			}
		}
	}

	@Override
	public Contact findContact(String firstName) {
		Contact contact = null;
		for(int i=0;i<contacts.length;i++){
			if(contacts[i] != null && contacts[i].getFirstName().equals(firstName)){
				contact = contacts[i];
				break;
			}
		}
		return contact;
	}

	@Override
	public void listAll() {
		System.out.println(Arrays.toString(contacts));	
	}
	@Override
	public void saveContact() throws IOException {
		File file = new File("C:\\Users\\dvorchu\\Capgemini\\ReadMe.txt");
		FileOutputStream fileInput = new FileOutputStream(file);
		ObjectOutputStream objectInput = new ObjectOutputStream(fileInput);
		
		
	}

	@Override
	public void loadContact() {
		// TODO Auto-generated method stub
		
	}
}
