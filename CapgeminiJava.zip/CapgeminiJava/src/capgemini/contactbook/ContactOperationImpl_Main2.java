package capgemini.contactbook;

import java.util.Scanner;

public class ContactOperationImpl_Main2 {
	
	static Scanner sc = new Scanner(System.in);

	public static String getInput(String message) {
		String input;
		System.out.println(message);
		input = sc.next();
		return input;
	}

	public static Contact getContact() {
		Contact contact = null;
		contact = new Contact();
		contact.setFirstName(getInput("Enter first name :"));
		contact.setLastName(getInput("Enter last name :"));
		contact.setEmail(getInput("Enter email:"));
		contact.setPhone(getInput("Enter phone no:"));
		return contact;
	}

	public static void main(String[] args) {
		ContactOperation contactOperation = new ContactOperationImpl(5);

		int choice = 0;
		do {
			System.out.println("***************");
			System.out.println("Welcome to contact Book...");
			System.out.println("1.ADD contact");
			System.out.println("2.List ALL");
			System.out.println("3.find contact");
			System.out.println("4.Delete contact");
			System.out.println("5.SaveAll");
			System.out.println("6.Restore All");
			System.out.println("7.Exit");
			System.out.println("***************");
			System.out.println("Enter Choice:");
			choice = sc.nextInt();
			Contact contact = null;
			switch (choice) {
			case 1:
				contactOperation.addContact(getContact());
				System.out.println("\t\t::==>Contact is created..");
				break;
			case 2:
				contactOperation.deleteContact(getInput("Entre name to delete:"));
				break;
			case 3:
				contactOperation.findContact(getInput("Entre name to find:"));
				System.out.println(contact);
				break;
			case 4:
				contactOperation.listAll();
				break;
			}
		} while (choice != 7);
	}
}