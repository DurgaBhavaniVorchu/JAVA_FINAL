package capgemini.contactbook;

import java.io.Serializable;

public class Contact implements Serializable {
	private String FirstName;
	private String LastName;
	private String Phone;
	private String Email;
	
	public Contact(String firstName, String lastName, String phone, String email){
		super();
		setFirstName(firstName);
		setLastName(LastName);
		setPhone(phone);
		setEmail(email);
	}

	public Contact() {
		// TODO Auto-generated constructor stub
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getPhone() {
		return Phone;
	}

	public void setPhone(String phone) {
		Phone = phone;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	@Override
	public String toString() {
		return "Contact [FirstName=" + FirstName + ", LastName=" + LastName + ", Phone=" + Phone + ", Email=" + Email
				+ "]";
	}
	
}
