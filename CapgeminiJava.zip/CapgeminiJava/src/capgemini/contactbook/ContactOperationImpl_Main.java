package capgemini.contactbook;

import java.util.Scanner;

public class ContactOperationImpl_Main {
	public static void main(String args[]){
		ContactOperation contactOperation = new ContactOperationImpl(3);
		int choice = 0;
		Scanner sc = new Scanner(System.in);
		do{
			System.out.println("Welcome to ContactBook");
			System.out.println("1.Add Contact");
			System.out.println("2.delete Contact");
			System.out.println("3.Find Contact");
			System.out.println("4.List all");
			System.out.println("5.Save All");
			System.out.println("6.Restore All");
			System.out.println("7.Exit");
			System.out.println("Enter Choice :");
			choice = sc.nextInt();
			
			switch(choice){
			case 1:
				Contact contact1 = new Contact("bhavani", "vorchu", "8639593317", "durga@gmail.com");
				contactOperation.addContact(contact1);
				System.out.println("\t\t::=>Contact is created.........");
				break;
			case 2:
				contactOperation.deleteContact("bhavani");
				break;
			case 3:
				contact1 = contactOperation.findContact("bhavani");
				System.out.println(contact1);
				break;
			case 4:
				contactOperation.listAll();
				break;
			}
		}while(choice != 7);
		
	}
}
