package capgemini.contactbook;

import java.io.IOException;

public interface ContactOperation {
	public void addContact(Contact contact);
	public void deleteContact(String firstName);
	public Contact findContact(String firstName);
	public void listAll();
	public void saveContact() throws IOException;
	public void loadContact();
}
