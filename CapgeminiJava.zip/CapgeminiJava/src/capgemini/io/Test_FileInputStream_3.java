package capgemini.io;
 import java.io.*;
public class Test_FileInputStream_3 {
	public static void main(String args[]){
		String message = ("We are learning java language......");
		File file = new File("C:\\Users\\dvorchu\\Capgemini\\ReadMe_2.txt");
		try {
			FileOutputStream fileOutput = new FileOutputStream(file);
			fileOutput.write(message.getBytes());
			fileOutput.flush();
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		System.out.println("File is written.....");
	}
}
