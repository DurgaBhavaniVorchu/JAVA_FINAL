package capgemini.io;
import java.io.*;
public class Test_FileInputOutputStream_2 {
	public static void main(String args[]){
		
		File file = new File("C:\\Users\\dvorchu\\Capgemini\\Data.txt");
		
		try (
			FileInputStream fileInput = new FileInputStream(file);
			ObjectInputStream objectInput = new ObjectInputStream(fileInput);
			)
		{
			Student s1 = (Student)objectInput.readObject() ;
			System.out.println(s1);
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		System.out.println("Student object is written...");
	}
}
