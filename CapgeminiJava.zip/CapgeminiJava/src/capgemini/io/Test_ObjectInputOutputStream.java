package capgemini.io;
import java.io.*;
public class Test_ObjectInputOutputStream {
	public static void main(String args[]){
		Student s1 = new Student(101, "ajay", 75.5f);
		File file = new File("C:\\Users\\dvorchu\\Capgemini\\Data.Out");
		try (
			FileOutputStream fileOutput = new FileOutputStream(file);
			ObjectOutputStream objectOutput = new ObjectOutputStream(fileOutput);
			)
		{
			objectOutput.writeObject(s1);
			objectOutput.flush();
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		System.out.println("Student object is written...");
	}
}
