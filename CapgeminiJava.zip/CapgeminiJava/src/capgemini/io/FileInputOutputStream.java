package capgemini.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileInputOutputStream {
	public static void main(String args[]){
		//fileInputStream_1();
		fileInputSream_2();
	}
	
	public static void fileInputSream_2() {
		File file = null;
		FileInputStream fileInput;
		file = new File("C:\\Users\\dvorchu\\Capgemini\\ReadMe.txt");
		
		
			try {
				fileInput = new FileInputStream(file);
				int input = 0;
				
				while((input = fileInput.read()) != -1) {
					System.out.print((char)input);
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
	}
}
