package capgemini.interfaces;

interface Calculator {
	//by default methods are public and abstract
	int add(int no1, int no2);   // no body
	public abstract int sub(int no1, int no2);
	default void defJdk8(){
		System.out.println("I am new feature in JDK 8 called default method");
	}
}

interface AdvCalculator{
	int mul(int no1, int no2);
	int div(int no1, int no2);
}


//interfaces are implements via class
class CalculatorImpl implements Calculator, AdvCalculator {
	// The type calculatorImpl must implements the inheritance abstract method
	//Calculator.add(int, int)
	@Override
	public int add(int no1, int no2) 
	{
		return no1 + no2;
	}
	
	@Override
	public int sub(int no1, int no2)
	{
		return no1 - no2;
	}
	
	@Override
	public int mul(int no1, int no2)
	{
		return no1 * no2;
	}
	
	@Override
	public int div(int no1, int no2)
	{
		return no1 / no2;
	}
}
 public class Calculator_Test {
	 public static void main(String args[])
	 {
		 
		 Calculator calc;
		 AdvCalculator advCalc;
		 
		 CalculatorImpl cal = new CalculatorImpl();
		 System.out.println("add:"+cal.add(4, 5));
		 System.out.println("sub:"+cal.sub(4, 5));
		 System.out.println("div:"+cal.div(4, 5));
		 System.out.println("mul:"+cal.mul(4, 5));
		 
		//ref pointer.....
		 //calc = calculatorImpl;
		 calc = new CalculatorImpl();
		 calc.defJdk8();
		 System.out.println("add:"+cal.add(4, 5));
		 System.out.println("sub:"+cal.sub(4, 5));
		 System.out.println("div:"+cal.div(4, 5));
		 System.out.println("mul:"+cal.mul(4, 5));
		 
		 //advCalc = calculatorImpl;
		 advCalc = new CalculatorImpl();
		 //System.out.println("add:"+cal.add(4, 5));
		 //System.out.println("sub:"+cal.sub(4, 5));
		 System.out.println("div:"+cal.div(4, 5));
		 System.out.println("mul:"+cal.mul(4, 5));
	 }
	 
	 
	 
 }
