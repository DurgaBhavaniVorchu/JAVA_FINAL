package capgemini.interfaces;

interface ArraySort {
	void sortAsc();
	void sortDesc();
}
class ArraySortImpl implements ArraySort{
	int[] nums;
	public ArraySortImpl(int[] nos)
	{
		nums = nos;
	}
	
	
	
	@Override
	public void sortAsc(){
		
			for (int i = 0; i < nums.length; i++) 
	        {
	            for (int j = i + 1; j < nums.length; j++) 
	            {
	                if (nums[i] > nums[j]) 
	                {
	                    int temp = nums[i];
	                    nums[i] = nums[j];
	                    nums[j] = temp;
	                }
	            }
	        }
			
			System.out.println("Ascending order of a given array:");
			for(int i=0;i<nums.length;i++){
				System.out.println(nums[i]);
			}
		}
	
	
		@Override
		public void sortDesc(){
		
			for (int i = 0; i <nums.length; i++) 
	        {
	            for (int j = i + 1; j < nums.length; j++) 
	            {
	                if (nums[i] < nums[j]) 
	                {
	                	int temp = nums[i];
	                    nums[i] = nums[j];
	                    nums[j] = temp;
	                }
	            }
	        }
			
			System.out.println("Descending order of a given array:");
			for(int i=0;i<nums.length;i++){
				System.out.println(nums[i]);
			}
		}
}


public class ArraySortTest{
	
	public static void main(String args[])
	{
		int[] a = {1, 2, 3, 4, 5};
		ArraySortImpl arr = new ArraySortImpl(a);
		arr.sortAsc();
		System.out.println();
		arr.sortDesc();
	}
}