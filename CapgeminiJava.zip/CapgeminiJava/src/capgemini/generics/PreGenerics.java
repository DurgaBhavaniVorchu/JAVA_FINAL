package capgemini.generics;
import java.util.*;

class PreGenerics {
	
	private Object t;
	
	public Object get(){
		return t;
	}
	public void set(Object t) {
		this.t = t;
	}
	
	public static void main(String args[]){
		PreGenerics type = new PreGenerics();
		type.set("bhavani");
		String str = (String) type.get();  // type casting, error prone and can
		System.out.println(str);
		type.set(1);
		int num=(int)type.get();
		System.out.println(num);
	}
}
