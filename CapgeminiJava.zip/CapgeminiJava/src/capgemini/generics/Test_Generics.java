package capgemini.generics;

import java.util.*;

abstract class Shape{
	abstract void draw();
}
class Rectangle extends Shape{
	void draw() {
		System.out.println("drawing Rectangle.........");
	}
}
class Circle extends Shape{
	void draw() {
		System.out.println("drawing Circle.........");
	}
}
class GenericTest {
	//creating a method that accepts only child class of shape
	public static void drawShapes(List<? extends Shape> lists){
		for(Shape shape:lists){
			shape.draw();//calling method of shape class by child class instance
		}
	}
	
	public static void main(String args[]){
		List<Rectangle> listRectangle = new ArrayList<Rectangle>();
		listRectangle.add(new Rectangle());
		
		List<Circle> listCirlce = new ArrayList<Circle>();
		listCirlce.add(new Circle());
		
		drawShapes(listRectangle);
		drawShapes(listCirlce);
	}
}
/*public class Test_Generics {
	
	public static void main(String args[]) {
		//PreGenerics.main(new String[0]);
		Test_Generics.main(new String[0]);
	}
}


/*JAVA Generic Type
E - Element
K Key
N number
T Type
V Value (used in maps)
S,U,V etc - 2nd, 3rd, 4th types*/
