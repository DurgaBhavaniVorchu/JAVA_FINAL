package capgemini.generics;

public class GenericsType<T> {
	
	private T t;
	
	public T get(){
		return t;
	}
	public void set(T t) {
		this.t = t;
	}
	
	public static void main(String args[]){
		PreGenerics type = new PreGenerics();  //raw type
		type.set("bhavani");  //valid
		type.set(10);   //valid and auto boxing support
		
		GenericsType<String>type1 = new GenericsType<>();
		type1.set("arunn");  //valid
		
		String str = (String) type1.get();  // type casting, not needed, No classCastExchanging
		System.out.println(str);
		//typr.set(1);  //errors,  not permitted in the type String
		
	}
}
