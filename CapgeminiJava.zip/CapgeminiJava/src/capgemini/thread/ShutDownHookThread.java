package capgemini.thread;

public class ShutDownHookThread {
	public static void main(String args[]){
		
		Runtime runTime = Runtime.getRuntime();
		runTime.addShutdownHook(new ShutDownHook());
		
		System.out.println("Now main sleeping...press ctrl+c to exit");
		try {
			Thread.sleep(3000);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}

class ShutDownHook extends Thread {
	public void run() {
		System.out.println("ShutDownHook TASK completed.....");
	}
}