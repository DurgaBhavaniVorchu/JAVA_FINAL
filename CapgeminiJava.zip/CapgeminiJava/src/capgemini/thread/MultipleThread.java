package capgemini.thread;

public class MultipleThread {
	public static void main(String args[]){
		
		System.out.println("Multiple Tread->Started......");
		
		//anonymous class implementation for runnable interface
		Runnable runnable = new Runnable(){
			@Override
			public void run() {
				System.out.println("RUNNABLE IS RUNNING ..........");
					
			}
		};
		Thread thread = new Thread(runnable);
		thread.start();
		
		//anonymous class implementation for thread class
		Thread thread1 = new Thread(){
			@Override
			public void run() {
				System.out.println("thread IS RUNNING ..........");
			}
		};
		thread1.start();
		
		System.out.println("multiple thread->ended");
	}
}
