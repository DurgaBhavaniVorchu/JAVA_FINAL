package capgemini.thread;

public class StopThread {
	public static void main(String args[]){
		System.out.println("StopThread->Started....");
		
		StoppableThread stoppableThread = new StoppableThread("StoppableThread");
		stoppableThread.start();
		
		try {
			Thread.sleep(10L * 1000L);
		}catch (Exception e) {
			e.printStackTrace();
		}
		stoppableThread.doStop();
		
		System.out.println("StoppableThread->ended");
	}
}
 class StoppableThread extends Thread{
	 private boolean doStop = false;
	 
	 public StoppableThread(String threadName) {
		 super(threadName);
	 }
	 public synchronized boolean doStop() {
		 return this.doStop = true;
	 }
	 public synchronized boolean keepRunning() {
		 return this.doStop = false;
	 } 
	 @Override
	 public void run() {
		 while (keepRunning()) {
			 //keep doing what this thread should do.
			 System.out.println(getName()+"->running...");
			 
			 try {
				 Thread.sleep(3L * 1000L);
			 }catch (Exception e) {
				e.printStackTrace();
			}
		 }
	 } 
 }