package capgemini.thread;

public class JoiningThread {
	public static void main(String args[]){
		System.out.println("JoiningThread->started....");
		
		Thread T1 = new ExtendedThread("T1");
		Thread T2 = new ExtendedThread("T2");
		
		System.out.println("T1 has started....");
		T1.start();
		
		try {
			System.out.println("T1 join.....");
			T1.join();
			System.out.println("T1 is done.....");
		}catch (InterruptedException e) {
			System.out.println(T1.getName()+" interrupted....");
		}
		
		System.out.println("T2 has started....");
		T2.start();
		try {
			System.out.println("T2 join.....");
			T2.join();
			System.out.println("T2 is done.....");
		}catch (InterruptedException e) {
			System.out.println(T2.getName()+" interrupted....");
		}
	}
}
