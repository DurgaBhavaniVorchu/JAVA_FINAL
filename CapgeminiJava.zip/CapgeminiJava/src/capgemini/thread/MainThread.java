package capgemini.thread;

public class MainThread {
	public static void main(String args[]){
		System.out.println("MainTread->Started........");
		
		//how to get the handle of main thread
		Thread currentThread = Thread.currentThread();
		System.out.println(currentThread.getId());
		System.out.println(currentThread.getName());
		System.out.println(currentThread.getPriority());
		
		currentThread.setName("Main Thread");
		currentThread.setPriority(Thread.MAX_PRIORITY);
		
		System.out.println(currentThread.getName());
		System.out.println(currentThread.getPriority());
		
		for(int i=0;i<10;i++){
			System.out.println(currentThread.getName()+":->"+i);
			try {
				Thread.sleep(1000);
			}catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("gm, sleep is over.....");
		}
		System.out.println("Main thread->end.....");
	}
}
