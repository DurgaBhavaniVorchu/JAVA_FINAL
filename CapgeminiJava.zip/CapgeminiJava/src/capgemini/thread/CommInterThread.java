package capgemini.thread;

public class CommInterThread {
	public static void main(String args[]){
		System.out.println("CommInterThread->started");
		
		Account account = new Account();
		
		new Thread() {
			public void run(){
				account.withdraw(15000);
			}
		}.start();
		new Thread() {
			public void run() {
				account.deposit(10000);
			}
		}.start();
		
		System.out.println("CommInterThread->ended");
	}
}
 class Account {
	 int Amount = 10000;
	 synchronized void withdraw(int amount) {
		 System.out.println("going to withdraw...");
		 
		 if(this.Amount < amount) {
			 System.out.println("Less balance; waiting for deposit....");
			 try {
				 wait();
			 } catch (Exception e) {
				 
			 }
		 }
		 this.Amount = amount;
		 System.out.println("withdraw completed....");
	 }
	 
	 synchronized void deposit(int amount){
		 System.out.println("going to deposit....");
		 this.Amount += amount;
		 System.out.println("deposit completed....");
		 notify();
	 }
	 
 }