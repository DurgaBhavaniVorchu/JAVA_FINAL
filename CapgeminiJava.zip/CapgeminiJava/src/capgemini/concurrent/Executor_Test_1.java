package capgemini.concurrent;
import java.util.concurrent.*;
public class Executor_Test_1 {

	public static void main(String args[]){
		System.out.println("Inside : "+Thread.currentThread().getName());
		
		System.out.println("Creating executor Service with single worker thread");
		//Executor executor = Executors.newSingleThreadExecutor();
		ExecutorService executorService = Executors.newSingleThreadExecutor();
		
		System.out.println("Creating a runnable...");
		Runnable task = new Runnable() {
			public void run() {
				System.out.println("Inside : "+Thread.currentThread().getName());
			}
		};
		
		System.out.println("submit the task specified by the runnable to the executor");
		//executor.execute(task);
		executorService.submit(task);
		
		System.out.println("Submitting down the executor");
		//executorServive shutdown();
	}
}
