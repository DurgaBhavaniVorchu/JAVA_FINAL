package capgemini.concurrent;


import java.util.concurrent.*;

public class Executor_Test_2 {
	public static void main(String args[]){
		System.out.println("Inside : " + Thread.currentThread().getName());
		
		System.out.println("Creating Executor service with a thread pool of size 2");
		//ExecutorService executorService = Executors.newFixedThreadPool(2);
		Executor executor = Executors.newFixedThreadPool(2);
		Runnable task1 = new Runnable() {
			public void run() {
				System.out.println("Executing task1 inside : " + Thread.currentThread().getName());
				try {
					TimeUnit.SECONDS.sleep(4);
				}catch(InterruptedException ex) {
					throw new IllegalStateException(ex);
				}
			}
		};
		
		Runnable task2 = new Runnable() {
			public void run() {
				System.out.println("Executing task2 inside : " + Thread.currentThread().getName());
				try {
					TimeUnit.SECONDS.sleep(3);
				}catch(InterruptedException ex) {
					throw new IllegalStateException(ex);
				}
			}
		};
		
		Runnable task3 = new Runnable() {
			public void run() {
				System.out.println("Executing task3 inside : " + Thread.currentThread().getName());
				try {
					TimeUnit.SECONDS.sleep(3);
				}catch(InterruptedException ex) {
					throw new IllegalStateException(ex);
				}
			}
		};

	
	System.out.println("Submitting the tasks for execution...");
	//executor.submit(task1);
	//executor.submit(task2);
	//executor.submit(task3);
	
	System.out.println("submitting down the executor");
	}
}
