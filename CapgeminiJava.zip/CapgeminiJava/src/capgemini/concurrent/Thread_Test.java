package capgemini.concurrent;

public class Thread_Test {
	public static void main(String args[]){
		//Implementing Runnable Interace
		Runnable runnable1 = new HelloRunnable();
		Thread runnableThread = new Thread(runnable1);
		runnableThread.start();
		
		//2. Implementing annonymous class
		Runnable runnable2 = new Runnable() {
			@Override
			public void run() {
				System.out.println("Hello annonymous.....");
			}
		};
		Thread annonymousThread = new Thread(runnable2);
		annonymousThread.start();
		
		//3. Implementing Lambda Expression
		Runnable runnable3 = ()->System.out.println("Hello Lambda...");
		Thread lambdaThread1 = new Thread(runnable3);
		lambdaThread1.start();
		
		Thread lambdaThread2 = new Thread(()->System.out.println("Lambda Wow"));
		lambdaThread2.start();
		
		
	}
}
class HelloRunnable implements Runnable {
	@Override
	public void run() {
		System.out.println("Hello Runnable");
	}
}
