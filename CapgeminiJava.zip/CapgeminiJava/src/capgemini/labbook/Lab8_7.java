package capgemini.labbook;

public class Lab8_7 
{
	public static boolean validate(String name)
	{
		String st  = name.substring(0,name.length()-4);
		if(name.substring(name.length()-4, name.length()).equals("_job")&&st.length()>=8)
		{
			return true;
		}
		else
			return false;
	}
	public static void main(String [] args)
	{
		System.out.print(validate("DurgaBhavani_job"));
	}
}
