package capgemini.labbook;
import java.util.Scanner;
interface Usernamepwd {
	boolean Usernamepassword(String user,String pwd);
	
}
public class Lab13_Exercise3 {
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	System.out.println("enter user name");
	String username=sc.nextLine();
	System.out.println("enter password");
	String password=sc.next();
	Usernamepwd up=(a,b) -> Authentication(a,b);
	if (up.Usernamepassword(username ,  password))
{
	System.out.println("Logged successfully");
	
}
else {

System.out.println("Logged failure");                            
	
}
sc.close();

}
 static boolean Authentication(String x, String y)
 {
	 boolean val=false;
	 String username="bhavani";
	 String password ="bhavani123";
	 if(x.equals(username) && y.equals(password))
	 {
		 return true;
	 }return val;
 }
}