package capgemini.labbook;

import java.util.Scanner;

public class Lab8_5 {
	public void counting(String str)
	{
		int i=0,f=0;
		char ch[] = str.toCharArray();
		int len= ch.length;
		for(i=0;i<len-1;i++)
		{
			char chr = ch[i];
			char b=ch[i+1];
			if(chr>=b)
			{
				f=1;
				break;
			}
		}
	
	if (f==0) {
		
	
	
		System.out.println("Positive String");
		}
	else
		System.out.println("not a Positive number");
	

}
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		String str=sc.nextLine().toUpperCase();
		Lab8_5 obj=new Lab8_5();
		obj.counting(str);
		sc.close();
	}
}
