package capgemini.labbook;

public class OddNumbers {
	public static void main(String args[])
	{
		int[] in={1,2,3,4,5};
		{
			for(int i=0;i<in.length;i++)
			{
				if(in[i]%2!=0)
				{
					System.out.println(in[i]);
				}
			}
		}
	}
}
