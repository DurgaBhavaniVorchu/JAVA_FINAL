package capgemini.labbook;
import java.util.*;
import java.util.Date;
public class Lab10_Exercise2  implements Runnable{
	 Thread kb=new Thread(this);
	public Lab10_Exercise2() throws InterruptedException{
		kb=new Thread(this);
		kb.start();
		
	}
	public void run() {
		Date date;
		while(true)
		{
			try {
				date = new Date();
				Thread.sleep(5000);
				System.out.println(date.getHours()+":"+date.getMinutes()+":"+date.getSeconds());
				
			}
			catch (InterruptedException e) {
				System.out.println("this should be not come");
				
			}
		}
		
	}
	public static void main(String args[]) throws InterruptedException
	{
		Lab10_Exercise2 exe= new Lab10_Exercise2();
		
	}

}
