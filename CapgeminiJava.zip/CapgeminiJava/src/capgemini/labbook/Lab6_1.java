package capgemini.labbook;

public class Lab6_1 {
	
}
