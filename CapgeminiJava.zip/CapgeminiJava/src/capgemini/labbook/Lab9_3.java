package capgemini.labbook;

import java.util.*;
import java.util.Scanner;
import java.util.HashMap;


public class Lab9_3 {
	public static void main(String args[])
	{ System.out.println("Enter the number of elements");
		Scanner sc = new Scanner(System.in);
		int a=sc.nextInt();
		System.out.println("Enter the  elements");
		int ch[] = new int[a];
		for(int i=0;i<a;i++)
		{
			ch[i]=sc.nextInt();
			
		}
		Square s= new Square();
		HashMap<Integer,Integer> hm=new HashMap<Integer,Integer>();
		hm=s.square(ch);
		for(Map.Entry mp : hm.entrySet())
		{
			int key = (int)mp.getKey();
			int count =(int) mp.getValue();
			System.out.println("Square of the " +key+" is :"+count);
		}
		
	}
}


class Square 
{
	HashMap square (int[]ch)
	{
		HashMap<Integer,Integer> h= new HashMap<Integer,Integer>();
		int length=ch.length;
		int square[]=new int [length];
		for(int i=0;i<length;i++)
		{
			square[i]=ch[i]*ch[i];
			h.put(ch[i], square[i]);
			
			
		}
		return h;
		
		
	

	}

}