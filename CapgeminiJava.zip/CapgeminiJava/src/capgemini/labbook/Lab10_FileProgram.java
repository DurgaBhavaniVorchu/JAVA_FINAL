package capgemini.labbook;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class Lab10_FileProgram {
	public static void main(String args[])
	{
		try {
			FileInputStream kbok=new FileInputStream("C:\\krishna/krishna.txt");
			FileOutputStream kbkk=new FileOutputStream("C:\\krishna\\pavan.txt");
			Lab10_CopyDataThread cdy= new Lab10_CopyDataThread(kbok,kbkk);
			cdy.start();
		}
	catch( Exception e)
		{
		System.out.println(e);
		
		}
		
	}
		

}
