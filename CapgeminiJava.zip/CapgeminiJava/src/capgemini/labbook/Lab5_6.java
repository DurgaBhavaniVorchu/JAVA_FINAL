package capgemini.labbook;

import java.util.*;
class EmployException extends RuntimeException
{
	EmployException()
	{
		System.out.println("salary should be above 3000");
		
	}
}

public class Lab5_6 {
public static void main (String args[]) throws Exception 
{
	Scanner sc= new Scanner (System.in);
	System.out.println("Enter salary");

	int sal=sc.nextInt();
	sc.close();
	try 
	{
		if(sal<3000)
			throw new EmployException();
		else
			System.out.println("salary: "+sal);
		
	}
	catch(Exception e) {
		System.out.println(e);
	}
	}
}
