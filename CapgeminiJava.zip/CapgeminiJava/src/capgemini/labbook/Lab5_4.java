package capgemini.labbook;

import java.util.Scanner;


public class Lab5_4 {
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		String fn="bhavani";
		String ln="vorchu";
		sc.close();
		try
		{
			if(fn==null || ln==null)
				System.out.println("First name and Last name should not be blank!!");
			else 
				System.out.println("firstname:  "+fn+ "lastname" +ln);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}

		
	}


}
