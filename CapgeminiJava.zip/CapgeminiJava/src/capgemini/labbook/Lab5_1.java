package capgemini.labbook;

enum Traffic {
	RED,GREEN,YELLOW;
}
class TrafficLight 
{
	Traffic color;
	public TrafficLight(Traffic color)
	{
		this.color=color;
	}
	public void selectColor()
	{
		switch(color)
		{
		case RED:
			System.out.println("STOP");
			break;
		case GREEN:
			System.out.println("GO");
			break;
		case YELLOW:
			System.out.println("READY");
			break;
			default:
				System.out.println("Wrong Selection ");
				break;
		}
	}
}
public class Lab5_1{
	public static void main(String args[]) 
	{
		TrafficLight t =new TrafficLight(Traffic.GREEN);
		t.selectColor();
	}
}

