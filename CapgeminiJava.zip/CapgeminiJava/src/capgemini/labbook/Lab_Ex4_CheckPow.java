package capgemini.labbook;

import java.util.*;
public class Lab_Ex4_CheckPow {
	
	public static boolean flag = false;
	public static int checkNumber(int n){
		 
		while(n%2 == 0){
				 n = n/2; 
		}
		if(n == 1)
			flag = true;
	 return n;
	}
	 public static void main(String args[]){
		 Scanner sc = new Scanner(System.in);
		 int n = sc.nextInt();
		 System.out.println("enter number:"+n);
		 checkNumber(n);
		 if(flag){
			 System.out.println(n+" is a power of 2");
		 }
		 else
			 System.out.println(n+" is not a power of 2");
	 }
}
