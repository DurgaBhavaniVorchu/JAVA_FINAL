package capgemini.labbook;

import java.util.*;
import java.text.SimpleDateFormat;
import java.time.*;


public class Lab8_6 {
	public static final String DATE_FORMAT_NOW = "yyyy-MM-dd";
	void setDate(Date d)
	{
		System.out.println();
		
	}
	public static String now() {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
		return sdf.format(cal.getTime());
	}
	public static void main(String args[])
	{
		SimpleDateFormat myFormat = new SimpleDateFormat("dd-MM-yyyy");
		Scanner sc = new Scanner(System.in);
		//String str = sc.nextLine();
		String str1 = now();
		try {
				String sDate1=sc.nextLine();
				Date date1=new SimpleDateFormat("dd-MM-yyyy").parse(sDate1);
				
		       Date dateBefore = myFormat.parse(sDate1);
		       System.out.println(sDate1);
		       Date dateAfter = myFormat.parse(str1);
		       
		       long difference =  dateBefore.getTime() - dateAfter.getTime();
		       
	               /* You can also convert the milliseconds to days using this method
	                * float daysBetween = 
	                *         TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS)
	                */
		       System.out.println("Number of Days between dates: "+difference);
		 } catch (Exception e) {
		       e.printStackTrace();
		 }
		
	}
	

}
