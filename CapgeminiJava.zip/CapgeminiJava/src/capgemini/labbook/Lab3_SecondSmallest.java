package capgemini.labbook;

public class Lab3_SecondSmallest {
	public static int getSecondSmallest(int[] nums){
		for (int i = 0; i < nums.length; i++) 
        {
            for (int j = i + 1; j < nums.length; j++) 
            {
                if (nums[i] > nums[j]) 
                {
                    int temp = nums[i];
                    nums[i] = nums[j];
                    nums[j] = temp;
                }
            }
        }
		 return nums[1];
	}
	public static void main(String args[]){
		int[] n = {3, 4, 2, 1, 5};
	System.out.println(getSecondSmallest(n));

	}
}
