package capgemini.labbook;

public class Lab_Ex3_IncreasingNum {
	
	public static boolean flag = false;
	public static int checkNumber(int n){
		
		int r = n%10;
		
		while(n>0){
			
			if(r < n%10){
				flag = true;
				break;
			}
			n=n/10;
		}
		return r;
	}
	
	public static void main(String args[]){
		
		checkNumber(12899);
		if(flag){
			 System.out.println("No");
		}
		
		else{
			System.out.println("Yes");
		}
	}
}
