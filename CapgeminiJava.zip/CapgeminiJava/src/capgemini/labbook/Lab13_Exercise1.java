package capgemini.labbook;
import java.util.*;

import java.lang.Math;

	interface summer
	{
	double sumof (double x,double y);
	}			
public class Lab13_Exercise1
{
public static void main(String args[])
{
	System.out.println("enter the elemnts");
		Scanner sc=new Scanner(System.in);
		double x=sc.nextInt();
		double y=sc.nextInt();
		sc.close();
	summer  s= (a,b)->Math.pow(a,b);
	double o= s.sumof(x,y);
	System.out.println(x+"power of "+y+"="+o);
	}
}