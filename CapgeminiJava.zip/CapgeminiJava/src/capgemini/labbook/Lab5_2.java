package capgemini.labbook;

import java.util.Scanner;


public class Lab5_2 {
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		int n=sc.nextInt();
		sc.close();
		Fib f= new Fib();
		long res= f.input(n);
		System.out.println("Non Recursive Function: "+res);
		int res1=f.recursive(n);
		System.out.println("Recursive Function: "+res1);
		
		
	}

}
  class Fib
  {
	  int n=1;
	  int b=1;
	  int c=0;
	  int count;
	  int input(int n) 
	  {
		  count =n;
		  count=fabo(count);
				  return count;
	  }
	  int fabo(int count)
	  {
		  if(count!=2)
		  {
			  c=n+b;
			  n=b;
			  b=c;
			  fabo(--count);
		  }
		  return c;
	  
	  }
	  int recursive(int n)
	  {
		  int res=0;
		  if(n==1)
		  
			  res=1;
			  else if (n==2)
				  res=1;
			  else
				  res= recursive(n-2)+recursive(n-1);
			  return res;
	  }
  }
