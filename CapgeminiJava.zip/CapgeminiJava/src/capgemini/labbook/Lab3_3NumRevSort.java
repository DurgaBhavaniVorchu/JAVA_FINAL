package capgemini.labbook;
import java.util.*;
public class Lab3_3NumRevSort {
	public static void main(String args[]){
		Scanner kb = new Scanner(System.in);
		int n = kb.nextInt();
		int[] array= new int[n];
		for(int i=0 ; i<n ; i++ ){
			array[i] = kb.nextInt();;
		}
		getSorted(array);
		for(int i=0;i<array.length;i++){
			System.out.println(array[i]);
		}
	}
	public static int[] getSorted(int[] n){
		for(int i=0;i<n.length;i++){
			int a=n[i];
			int r = 0;
			while(a>0){
				r = r*10+a%10;
				a=a/10;
			}
			n[i]=r;
		}
		for(int i=0;i<n.length;i++){
			for(int j=i;j<n.length;j++){
				if(n[i]>n[j]){
					int temp = n[i];
					n[i]=n[j];
					n[j]=temp;
				}
			}
		}
		return n;
		}
	}
