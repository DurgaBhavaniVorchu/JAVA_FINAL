package capgemini.labbook;

import java.util.Scanner;
import java.io.File;
class Lab8_4
{
	public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        String fileName = scan.next();
        File file = new File(fileName);
        System.out.println("File " + (file.exists() ? "exists" : "Not exists"));
        System.out.println("File is " + (file.canRead() ? "Readable" : "Not Readable"));
        System.out.println("File is " + (file.canWrite() ? "Writable" : "Not Writable"));
        System.out.println("File " + (file.isFile() ? "File" : "Directory"));
        System.out.println("File size " + file.length() + " Bytes");
        scan.close();
    }
}