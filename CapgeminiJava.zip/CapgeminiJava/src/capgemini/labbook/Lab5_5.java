package capgemini.labbook;

import java.util.Scanner;

public class Lab5_5
{
public static void main(String args[]) {
	Scanner sc= new Scanner(System.in);
	int age=sc.nextInt();
	sc.close();
	try 
	{
		if (age<15)
			System.out.println("AGe should be above 15");
		else
			System.out.println("Valid Age");
	}
	catch (Exception e)
	{
		System.out.println(e);
		
	}
}
}
