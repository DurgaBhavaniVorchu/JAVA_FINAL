package capgemini.labbook;

import java.util.*;
import java.io.*;


import java.io.*;
public class Lab8_2 {
	public void readRAF()throws IOException{
		int LineNumber = 1;
		try {
			RandomAccessFile kbObj=new RandomAccessFile("C:\\Users\\dvorchu\\Capgemini\\ReadMe.txt","r");
			String b;
			while((b=kbObj.readLine())!=null) {
				System.out.println(LineNumber);
				System.out.println(b);
				LineNumber++;
				
			}
			kbObj.close();
			
		}
		catch (Exception e)
		{
			System.out.println(e);
			

			}
	}

	
public static  void main(String args[]) throws IOException
{
	Lab8_2 kb= new Lab8_2();
	kb.readRAF();
}
}


	