package capgemini.labbook;

public class Lab_Ex2_SumSquare {
	
	public static int calculateDiffernce(int[] n){
		
		int sum=0;
		int sumSqu = 0;
		int sumWholeSqu = 0;
		for(int i=0;i<n.length;i++){
			
			sumSqu += n[i]*n[i];
			
			sumWholeSqu += n[i];
		}
		
		sum = sumSqu - (sumWholeSqu*sumWholeSqu);
		return sum;
	}
	public static void main(String args[]){
		
		int[] n = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		System.out.println(calculateDiffernce(n));
	}
}
