package capgemini.labbook;
import java.util.*;
public class Lab4_Exercise {
	Scanner sc = new Scanner(System.in);
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		cube(n);
	}
	public static void cube(int n) {
		int sum = 0;
		while(n>0){
			int r; 
			r = n%10;
			sum += r*r*r;
			n=n/10;
		}
		System.out.println(sum);
	}
}