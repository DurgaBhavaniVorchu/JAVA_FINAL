package capgemini.javabeans;

public class Rectangle {
	
	//fields.....
	private float length, breadth;
	
	//default.......
	public Rectangle(){
		//call another constructor........
		this(0.0f, 0.0f);//will call param constructor..
		System.out.println("Rectangle->def.....");
	}
	public Rectangle(float length, float breadth){
		//this.length = length;
		//this.breadth = breadth;
		setLength(length);
		setBreadth(breadth);
		System.out.println("Rectangle->param.....");
	}
	
	//getter and setter methods.......
	public void setLength(float length) {
		if(length > 0)
			this.length = length;
	}
	public float getLength() {
		return length;
	}
	public void setBreadth(float breadth) {
		if(breadth > 0)
			this.breadth = breadth;
	}
	public float getBreadth() {
		return breadth;
	}
	
	public double calArea(){
		return length*breadth;
	}
	public String toString(){
		return "length:"+getLength()+"breadth:"+getBreadth();
	}

	@Override
	public boolean equals(Object obj){
		if(this == obj)   //r1.equals(r1);
			return true;
		if(obj == null)   //r1.equals(null);
			return false;
		if(getClass() != obj.getClass())
			return false;
		Rectangle otherRect =  (Rectangle)obj;
		if(length != otherRect.length)
			return false;
		if(breadth != otherRect.breadth)
			return false;
		return true;
		
	}
	
	public static Rectangle whoisBiggerOne(Rectangle rectOne, Rectangle rectTwo){
		if(rectOne.getLength() > rectTwo.getLength()){
			return rectOne;
		}
		else{
			return rectTwo;
		}
	}
		
}
