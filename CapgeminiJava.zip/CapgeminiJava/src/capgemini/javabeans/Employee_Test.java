package capgemini.javabeans;

public class Employee_Test {
	public static void main(String args[]){
		
		Employee e1, e2, e3;
		
		e1 = new Employee("bhavani");
		e2 = new Employee("Sampath");
		e3 = new Employee("Krishna");
		
		System.out.println(e1.toString());
		System.out.println(e2.toString());
		System.out.println(e3.toString());
		
		System.out.println("The last employee ID is : "+Employee.SEQUENCE);
		System.out.println("Total count : "+Employee.getCount());
	}
}
