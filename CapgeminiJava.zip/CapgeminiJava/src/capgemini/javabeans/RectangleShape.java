package capgemini.javabeans;


	class RectangleShape extends Shape {
		private float length;
		private float breadth;


		public void setLength(float length) {
			this.length = length;
		}

		public float getLength() {
			return length;
		}

		public void setBreadth(float breadth) {
			this.breadth = breadth;
		}
		
		public float getBreadth() {
			return breadth;
		}
		
		public double calArea() {
			return length*breadth;
		}
	}
