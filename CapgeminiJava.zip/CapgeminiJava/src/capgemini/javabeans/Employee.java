package capgemini.javabeans;

public class Employee {
	
	private int empId;
	private String name;
	public static int SEQUENCE;
	public static int COUNT;
	
	static {
		SEQUENCE = 100;
		COUNT=0;
		System.out.println("I am in static block.....");
	}
	
	public Employee() {
		super();
		this.empId = ++SEQUENCE;
		COUNT++;
		System.out.println("I am in def consructor.....");
	}
	
	public Employee(String name) {
		super();
		this.empId = ++SEQUENCE;
		COUNT++;
		this.name = name;
		if(COUNT==1)
			System.out.println("I am in param consructor.....");
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public static int getCount() {
		return COUNT;
	}
	
	
	public String toStringChain() {
		StringBuilder builder = new StringBuilder();
		builder.append("Employee [empId=").append(empId).append(", name=").append(name).append("]");
		return builder.toString();
	}

	
	public String toStringBuilder() {
		StringBuilder builder = new StringBuilder();
		builder.append("Employee [empId=");
		builder.append(empId);
		builder.append(", name=");
		builder.append(name);
		builder.append("]");
		return builder.toString();
	}
	
	public String toStringBuffer() {
		StringBuffer Buffer = new StringBuffer();
		Buffer.append("Employee [empId=");
		Buffer.append(empId);
		Buffer.append(", name=");
		Buffer.append(name);
		Buffer.append("]");
		return Buffer.toString();
	}
	
}
