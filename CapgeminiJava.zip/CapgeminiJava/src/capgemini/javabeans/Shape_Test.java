package capgemini.javabeans;

public class Shape_Test {
	public static void main(String args[])
	{
		Circle c1,c2;
		c1 = new Circle();
		c2 = new Circle();
		
		c1.getRadius();
		c1.setRadius(4.0f);
		System.out.println(c1.calArea());
		
		c2.getRadius();
		c2.setRadius(4.0f);
		System.out.println(c2.calArea());
		
		Rectangle r1, r2;
		
		r1 = new Rectangle();
		r2 = new Rectangle();
		
		r1.getLength();
		r1.setLength(4.0f);
		r1.getBreadth();
		r1.setBreadth(4.0f);
		System.out.println(r1.calArea());
		
		r2.getLength();
		r2.setLength(4.0f);
		r2.getBreadth();
		r2.setBreadth(4.0f);
		System.out.println(r2.calArea());
		
		Triangle t1 = null;
		t1.getBase();
		t1.setBase(4.0f);
		t1.getHeight();
		t1.setHeight(4.0f);
	}
}
