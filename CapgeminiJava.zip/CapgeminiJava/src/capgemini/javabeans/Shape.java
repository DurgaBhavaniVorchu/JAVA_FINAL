package capgemini.javabeans;

public abstract class Shape {
	
	//def constructor........
	public Shape() {
		System.out.println("def constructor....");
	}
	 //method......
	public void draw() {
		System.out.println("shape id draw...");
	}
	
	//abstract method......
	public abstract double calArea();
}

class Circle extends Shape {
	private float radius;
	
	public void setRadius(float radius) {
		this.radius = radius;
	}
	public float getRadius() {
		return radius;
	}
	public double calArea() {
		return radius*radius*Math.PI;
	}
}

class Triangle extends Shape {
	private float base;
	private float height;
	
	public float getBase() {
		return base;
	}
	public void setBase(float base) {
		this.base = base;
	}
	public float getHeight() {
		return height;
	}
	public void setHeight(float height) {
		this.height = height;
	}
	
	public double calArea()
	{
		return (1/2)*base*height;
	}
}
