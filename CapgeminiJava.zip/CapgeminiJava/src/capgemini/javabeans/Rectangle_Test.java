package capgemini.javabeans;

public class Rectangle_Test {
	public static void main(String args[]){
		//declaration
		Rectangle r1,r2;
		//object innitiallization...
		r1 = new Rectangle(4.5f, 5.5f);
		r2 = new Rectangle(5.5f, 6.5f);
		//accessing fields of an onject
		//r1.length = 5.5f;
		r1.setLength(5.5f);
		r1.getLength();
		r1.setBreadth(5.5f);
		r1.getBreadth();
		
		r2.setLength(4.5f);
		r2.getLength();
		r2.setBreadth(4.5f);
		r2.getBreadth();
		//accessing method of an object
		
		System.out.println(r1.calArea());
		System.out.println(r1.toString());
		System.out.println(r2.calArea());
		System.out.println(r2.toString());
		System.out.println(r1.equals(r2));
		Rectangle bigger1 = Rectangle.whoisBiggerOne(r1, r2);
		Rectangle bigger2 = ShapeUtility.whoisBiggerTwo(r1, r2);
		
	}
}
