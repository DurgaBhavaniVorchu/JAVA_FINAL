package capgemini.stream;

public class Vowels {
	public static void main(String args[]){
		String str = "Welcome";
		char[] ch = str.charAt[0];
	}
}
