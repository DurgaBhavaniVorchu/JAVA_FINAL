package capgemini.stream;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;
public class BasicStream {
	public static void main(String args[]){
		//generate an int array of 10
		Integer[] array = new Integer[10];
		for(int i=0;i<array.length;i++){
			array[i] = (int) (Math.random()*100);
		}
		
		array = new Integer[] {1, 2, 3, 4, 5, 5, 4, 3, 2, 1};
		//  obtaining a stream
		Stream<Integer> stream = Arrays.stream(array);
		Stream<Integer> stream1= Arrays.stream(array);
		//   consumer -> lambda expression
		//stream.forEach((value) -> System.out.print(value+" "));
		
		//stream.forEach(System.out::println);  // method reference
		
		//stream.distinct().forEach(System.out::println);
		//stream.distinct().limit(3).forEach(System.out::println);
		
		//Predicate<Integer> oddPredecate = (value) -> value%2!=0;
		//stream.distinct().filter(oddPredecate).forEach(System.out::println);
		//long count = stream.count();
		
		// print min
		stream1.sorted().limit(1).forEach(System.out::println);
		
		//print max
		Comparator<Integer> comp = (num1, num2) -> (num2>num1?-1:0);
		Optional<Integer> optionalMax = stream.max(comp);
		System.out.println(optionalMax.get());
		
		int num1 = 10;
		int num2 = 20;
		int max = num1>num2?num1:num2;
	}
}
