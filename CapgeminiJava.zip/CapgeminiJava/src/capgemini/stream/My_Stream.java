package capgemini.stream;

import java.util.function.Consumer;

public class My_Stream {
	public static void main(String args[]){
		//generate an int array of 10
		int[] array = new int[10];
		for(int i=0;i<array.length;i++){
			array[i] = (int) (Math.random()*100);
		}
	
		for(int i=0;i<array.length;i++){
			System.out.println(array[i]);
		}
		System.out.println("Consumer int action......");
		Consumer<Integer> consumer = 
				(Integer value) -> System.out.print(value+" ");
				for(int i=0;i<array.length;i++){
					consumer.accept(array[i]);
				}
		
		
	}
}
