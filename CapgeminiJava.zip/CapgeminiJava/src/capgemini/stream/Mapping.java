package capgemini.stream;

import java.util.Arrays;
import java.util.List;

public class Mapping {
	public static void main(String args[]){
		List<String> locations = Arrays.asList(new String[]{"pune", "mumbai", "chennai", "banglore", "Noida"});
		System.out.println("word length for location:");
		locations.stream().map(String::length).forEach(System.out::println);
		
		//locations.stream().map(City::new).forEach(System.out::print);
	}
}
