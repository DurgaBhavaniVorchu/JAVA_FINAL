package capgemini.stream;

import java.util.ArrayList;
import java.util.stream.Collectors;
import java.util.List;
import java.util.Set;
public class CollectionLambda {
	public static void main(String args[]){
		List<String> cities = new ArrayList<>();
		cities.add("pune");
		cities.add("Banglore");
		cities.add("mumbai");
		cities.add("chennai");
		
		
		//cities.parallelStream().forEach(city-.System.out::println(city));
		/*List<String> collect = cities.stream().distinct().collect(Collectors.toList());
		System.out.println(collect);*/
		//cities.forEach(city->System.out::println(city));
		
		Set<String> set = cities.stream().collect(Collectors.toSet());
		System.out.println(set);
	}
}
