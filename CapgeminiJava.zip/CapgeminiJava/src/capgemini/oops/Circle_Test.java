package capgemini.oops;

class Circle {
	//fields
	float radius;
	
	//Constructor
	public Circle(){
		radius = 0.0f;
		System.out.println("cirlce=>def...");
	}
	
	//Constructor overloading.....
	public Circle (float pradius){
		radius = pradius;
		System.out.println("circle->parameterrized");
	}
	//methods.........
	
	public void draw()
	{
		System.out.println("circle is draw...");
	}
	
	public double calcArea(){
		return radius*radius*Math.PI;
	}
	//method overriding from parent objct class
	@Override      //Java annotation
	public String toString(){
		return "Radius:" + radius;
	}

	//if(c1.equals(c2))
	@Override
	public boolean equals(Object obj) {
		Circle otherCircle = (Circle) obj;
				if(this.radius == otherCircle.radius){
					return true;
				}
				else {
					return false;
				}
	}
}




public class Circle_Test{
	public static void main(String args[])
	{
		//Declaration
		Circle c1,c2;
		
		//object initiallization
		c1 = new Circle();
		c2 = new Circle(2.2f);
		
		System.out.println("****object Array****");
		//array of objects......
		//declaration.........
		Circle[] circles;
		//initiallization.....
		circles = new Circle[2];
		circles[0] = new Circle(5.5f);
		circles[1] = new Circle(8.5f);
		
		for(int i=0; i<circles.length;i++)
		{
			circles[i].draw();
			System.out.println(circles[i].calcArea());
		}
		for (Circle circle:circles){
			circle.draw();
			System.out.println(circle.calcArea());
		}
		//calling instance methods.....
		c1.draw();
		System.out.println("c1 Area:" + c1.calcArea());
		c2.draw();
		System.out.println("c2 Area:" + c2.calcArea());
		
		System.out.println(c1.toString());
		System.out.println(c2.toString());
		
		if(c1.equals(c2))
		{
			System.out.println("c1 Equals to c2");
		}
		else 
		{
			System.out.println("c1 not Equals to c2");
		}
	}
}