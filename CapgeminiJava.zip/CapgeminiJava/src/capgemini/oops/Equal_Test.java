package capgemini.oops;

public class Equal_Test {
	
	public static void main(String args[])
	{
		
		String name = "Capgemini";
		String Company = new String("Capgemini");
		
		if(name == Company)
		{
			System.out.print("Your are an Employee.........");
		}
		else
		{
			System.out.println("Your are not an Employee.........");
		}
		if(name.equals(Company)){
			System.out.println("Capgemini->Your are an Employee.........");
		}
		else
		{
			System.out.println("Capgemini->Your are not an Employee.........");
		}
		int score = 35;
		if(score == 35){
			System.out.println("Great Hero.....");
		}
		boolean isPass = true;
		if(isPass == true){
			System.out.println("pass.....");
		}
		char gender = 'M';
		if(gender == 'M');
		{
			System.out.println("Male......");
		}
	}

}
