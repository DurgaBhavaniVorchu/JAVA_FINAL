package capgemini.oops;

class Student {

	int rollNo;
	String name;
	float marks;
	
	final float OUT_OF_MARKS = 300;
	
	// constructor
	public Student(){
		System.out.println("default_Constructor.....");
		rollNo = 0;
		name = null;
		marks = 0.0f;
	}
	
	//parameterized constructor
	public Student(int r, String n, float m){
		rollNo = r;
		name = n;
		marks = m;
		System.out.println("parameterized_Constructor.....");
	}
	
	//method.......
	public void display()
	{
		System.out.println(rollNo);
		System.out.println(name);
		System.out.println(marks);
	}
	
	public double calPercentage(){
		double percentage = (marks/OUT_OF_MARKS)*100;
		return percentage;
	}
	 
	public String calGrade()
	{
		double percentage = calPercentage();
		if(percentage >=90){
			return "A";
		}
		else if(percentage>=80){
			return "B";
		}
		else if(percentage>=70){
			return"c";
		}
		else
		{
			return "fail";
		}
	}
	
	
	
	 @Override
	public String toString() {
		return "Student rollNo=" + rollNo + ", name=" + name + ", marks=" + marks + ", OUT_OF_MARKS=" + OUT_OF_MARKS
				+ "]";
	}

	@Override
	 public boolean equals(Object obj) {
		 Student otherStu = (Student) obj;
		 if(this.rollNo == otherStu.rollNo && this.name == otherStu.name && this.marks == otherStu.marks)
		 {
			 return true;
		 }
		 else
		 {
			 return false;
		 }
		
	 }
}

public class Student_Test{
	
	public static void main(String args[]){
		
		//Declaration......
		Student s1,s2;
		
		//object initiallizatio.........
		s1 = new Student();
		s2 = new Student(2,"bhavani",245.0f);
		
		//calling of method........
		s1.display();
		System.out.println("s1 percentage:"+s1.calPercentage());
		System.out.println("s1 Grade:"+s1.calGrade());
		System.out.println(s1.toString());

		
		s2.display();
		System.out.println("s2 percentage:"+s2.calPercentage());
		System.out.println("s2 Grade:"+s2.calGrade());
		System.out.println(s2.toString());
		
		if(s1.equals(s2))
		{
			System.out.println("equals");
		}
		else
		{
			System.out.println("not equals");
		}
	}
}












