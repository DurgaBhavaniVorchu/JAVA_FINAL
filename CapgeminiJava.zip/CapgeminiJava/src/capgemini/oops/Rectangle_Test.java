package capgemini.oops;

 class Rectangle {
	
	//fields...
	float length, breadth;
	 
	//Constructor
	public Rectangle(float plength, float pbreadth)
	{
		length = plength;
		breadth = pbreadth;
	}
	
	//method....
	public float calArea(){
		return length*breadth;
	}
	
	//method overriding from parent objct class
		@Override      //Java annotation
		public String toString(){
			return "length:" + length+"\breadth:"+breadth;
		}
	
	@Override
	public boolean equals(Object obj) {
		Rectangle otherRect = (Rectangle)obj; 
		if(this.length == otherRect.length && this.breadth == otherRect.breadth){
			return true;
		}
		else {
			return false;
		}
	}
}

public class Rectangle_Test{
	
	public static void main(String args[])
	{
		//Declaration...
		Rectangle r1,r2;
		
		//object intiallization......
		r1 = new Rectangle(2.0f,5.0f);
		r2 = new Rectangle(3.0f,7.0f);
		
		//calling instance methods......
		System.out.println(r1.calArea());
		System.out.println(r2.calArea());
		
		if(r1.equals(r2))
		{
			System.out.println("r1 Equals to r2");
		}
		else 
		{
			System.out.println("r1 not Equals to r2");
		}
		
	}
	

 }
