package capgemini.java8.functional;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Test_LambdaExpression {
	public static void main(String args[]) {

		Runnable runnable = new Runnable() {

			@Override
			public void run() {
				System.out.println("Runnable...");

			}
		};
		Callable<String> callable = new Callable<String>() {
			@Override
			public String call() throws Exception {
				System.out.println("Callable....");
				return "Callable Done";
			}
		};

		// Implements runnable -> lambda Expression...
		/*
		 * Runnable runnable1 = () -> System.out.println("Runnable..."); Thread
		 * thread = new Thread(runnable); thread.start();
		 */

		Thread thread = new Thread(() -> System.out.println("Runnable....."));
		thread.start();

		// Implements Callable -> lambda Expression...
		/*
		 * Callable<String> callable1 = () -> {
		 * System.out.println("Callable..."); return "Done";
		 * 
		 * };
		 */
	
		 Callable<String> callable1 = () -> {
			  System.out.println("Callable...");
			  return "Done";
			 
		 };
		ExecutorService executorSrevice = Executors.newSingleThreadExecutor();
		executorSrevice.submit(callable);
		executorSrevice.shutdown();
	}

}
