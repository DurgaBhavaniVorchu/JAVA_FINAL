package capgemini.java8.functional;
import java.util.function.*;
public class ConstructorReference_Test {
	public static void main(String args[]) {
		//Constructor referencing....
		Supplier<Item> supplierItem = Item::new;
		System.out.println(supplierItem.get());
		Item item = supplierItem.get();
		item.setItemId(101);
		item.setName("Laptop");
		item.setCost(5555.555f);
		System.out.println(item);
	}
	
}
