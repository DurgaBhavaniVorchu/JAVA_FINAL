package capgemini.java8.functional;

//@FunctionalInterface
interface Hello {
	void sayHello();
//	void sayHi();
}

/*
 * class HelloImpl implements Hello {
 * 
 * @Override public void sayHello() {
 * System.out.println("HelloImpl->Hello....."); } }
 */

public class Test_FunctionalInterface {
	public static void main(String args[]) {
		// Before JDK 0
		// Hello hello = new HelloImpl();
		// hello.sayHello();
		// implementing of annonymous class.....
		/*
		 * Hello hello1 = new Hello() {
		 * 
		 * @Override public void sayHello() {
		 * System.out.println("annonymous->Hai..."); } };
		 * 
		 * Hello hello2 = new Hello() {
		 * 
		 * @Override public void sayHello() {
		 * System.out.println("annonymous->Hello..."); } };
		 * 
		 * Hello hello3 = new Hello() {
		 * 
		 * @Override public void sayHello() {
		 * System.out.println("annonymous->how are you..."); } };
		 * 
		 * hello1.sayHello(); hello2.sayHello(); hello3.sayHello();
		 */
		
		//Type Inference......
		Hello hello4 = () -> System.out.println("annonymous->Hai...");
		Hello hello5 = () -> System.out.println("annonymous->Hello...");
		Hello hello6 = () -> System.out.println("annonymous->How are you...");

		hello4.sayHello();
		hello5.sayHello();
		hello6.sayHello();

	}
}
