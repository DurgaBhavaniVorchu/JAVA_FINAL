package capgemini.java8.functional;
import java.util.*;



public class SortArrays {

 

    public static void main(String[] args) {
        List <String> weekdays=Arrays.asList("Mon","Tue","Wed", "Thu", "Fri", "Sat");
        System.out.println("Natural order:"+weekdays);
        
        Collections.sort(weekdays);
        System.out.println("Ascending order: "+weekdays);
        
        /*Comparator<String> descComparator=new Comparator<String>(){
            @Override
            public int compare(String str1, String str2) {
                
                return str2.compareTo(str1);
            }
        };
        */
        Comparator<String> descComparator=(String str1,String str2)->{
            return str2.compareTo(str1);
        };
        
            Collections.sort(weekdays,descComparator);
            System.out.println("Descending order:"+weekdays);
            
            //printAsc(weekdays,descComparator);
            printAsc(weekdays);
            printDesc(weekdays, descComparator);
            
            //foreach
    //lambda usage in iteration of collection
    /*for(String day:weekdays){
        System.out.println(day);
    }*/
    weekdays.forEach((day)->System.out.println(day));
    
    //passing consumer interface implementation as method references
    // to for each loop...
    weekdays.forEach(System.out::println);
    }
            private static void printAsc(List<String> weekdays) {
                Collections.sort(weekdays);
                System.out.println("Ascending order:"+weekdays);
            }
            
            private static void printDesc(List<String> weekdays, Comparator<String> descComparator) {
                Collections.sort(weekdays,descComparator);
                System.out.println("Descending order:"+weekdays);
            }
}