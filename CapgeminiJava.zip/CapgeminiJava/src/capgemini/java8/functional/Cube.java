package capgemini.java8.functional;
import java.util.*;
interface Calculator{
	public int add(int no1, int no2);
}


public class Cube {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int n1 = sc.nextInt();
		int n2 = sc.nextInt();
		sc.close();
		
		Calculator calc = new Calculator() {
			
			@Override
			public int add(int no1, int no2) {
				
				return n1 + n2;
			}
		};
		Calculator calc1 = (int no1, int no2) -> {
			return n1 + n2;
		};
		
		Calculator calc2 = (no1, no2) -> {
			return n1 + n2;
		};
		
		System.out.println(calc2.add(n1, n2));
	}
}
