package capgemini.lang;

import capgemini.javabeans.Employee;
public class MySystem {
	public static void main(String args[]){
		System system;
		//system = new System();    // can not be instantiated
		
		long startMemory = Runtime.getRuntime().freeMemory();
		long startTimeMillis = System.currentTimeMillis();
			
		System.out.println("Start Memory:"+startMemory);
		System.out.println("Start Time:"+startTimeMillis);
		
		//consuming memory......
		for(int i=0;i<10; i++) {
			new Employee();
		}
		System.out.println("last employee Id"+Employee.SEQUENCE);
		System.out.println("Total employee Count"+Employee.COUNT); // 3
		
		long endTimeMillis = System.currentTimeMillis();
		long endMemory = Runtime.getRuntime().freeMemory();
		
		System.out.println("End memory:"+endMemory);
		System.out.println("End Time:"+endTimeMillis);
		
		System.exit(0);
	}
}
