package capgemini.lang;

public class SimpleString {
	private static final String String = null;

	public static void main(String args[]){
		String s1 = "JAVA";
		String s2 = "JAVA";
		String s3 = new String("JAVA");
		
		//char[] Value = new char[] {'j', 'a', 'v', 'a'};
		char[] Value = {'j', 'a', 'v', 'a'};
		String s4 = new String(Value);

		String s5 = new String(s4);
		
		if(s1 == s2) {   // Values are same and memory klocation are also same
			System.out.println("s1 == s2");
		}
		
		if(s1 != s3) {
			System.out.println("s1 != s3");
		}
		
		System.out.println("s1 equals s2" + (s1.equals(s2)));  //true
		System.out.println("s1 equals s3" + (s1.equals(s3)));   //true
		System.out.println("Length of String s2 : " + s2.length());
		System.out.println("Index of v : " + s2.indexOf('V'));
		System.out.println("s2 in uppercase : " + s2.toUpperCase());
		System.out.println("Character at position 2 is : " + s2.charAt(1));
		System.out.println("Concatinating of s1 and s2 :" + s1.concat("JDK8"));
		System.out.println("Ending with:" + s1.endsWith("A"));
		System.out.println("Bytes:" + s1.getBytes());
		System.out.println("Empty:" + s1.isEmpty());
		System.out.println("Length:"+ s2.length());
		System.out.println("Split:"+ s1.split(s5));
		System.out.println("Strats with:" + s1.startsWith("J"));
		

	}
}
