//Author: Nadeem Shaik
//Date:24July2019
//Purpose: use for loop.........
//         to print arraylists
import java.util.Arrays;
public class Array {
	public static int min(int[] n)
	{
		int minVal=n[0];
		for(int i=1;i<n.length;i++)
		{
			
			if(n[i]<minVal)
			{
				minVal=n[i];
			}
		}
		return minVal;
	}
	public static void main(String args[])
	{
		int[] nums={1, 2, 3, 4, 5};
		int Min = min(nums);
		System.out.println("Min : "+Min);
		for(int num:nums)
		{
			System.out.println(num);
		}
		
		char[] vowels={'A', 'E', 'I', 'O', 'U'};
			System.out.println(Arrays.toString(vowels));
		String[] country={"India", "China", "Japan"};
			System.out.println(Arrays.toString(country));
		
	}

}
