import java.util.*;
public class RemoveDuplicate 
{

	
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		int n= sc.nextInt();
		String[] input = new String[100];
		for(int i=0;i<n;i++){
			input[i] = sc.nextLine();
			
		}
		sc.close();
		String[] words = new String[100];
		for(int i=0;i<n;i++){
			words=input[i].split(" ");
			for(int j=0;j<words.length;j++)		
			{
				if(words[i]!=null)
				{
				
					for(int k=i+1;k<words.length;k++)	
					{
					
						if(words[i].equals(words[j]))	
						{
							words[j]=null;			
						}
					}
				}
			}
		}
		
		for(int k=0;k<words.length;k++)		
		{
			if(words[k]!=null)
			{
				System.out.print(words[k]+" ");
			}
			
	     }  
	}
}
