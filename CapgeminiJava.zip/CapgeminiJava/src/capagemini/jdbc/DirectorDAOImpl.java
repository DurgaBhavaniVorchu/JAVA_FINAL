package capagemini.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

 

public class DirectorDAOImpl {
    
    Connection connection;
    
    public DirectorDAOImpl(){
        String url="jdbc:oracle:thin:@localhost:1521/xe";
        String username="INVENTORY1";
        String password="INVENTORY1";
        
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
             connection = DriverManager.getConnection(url,username,password);
             connection.setAutoCommit(false);
             System.out.println("Database connection established");
        } catch(ClassNotFoundException e){
            e.printStackTrace();
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
    public void save(int dirNumber, String dirName){
        String SQL="INSERT INTO DIRECTOR VALUES(?,?";
        PreparedStatement pstat;
        try{
            pstat=connection.prepareStatement(SQL);
            pstat.setInt(1, dirNumber);
            pstat.setString(2, dirName);
            
            int rows=pstat.executeUpdate();
            
            connection.commit();
            pstat.close();
            
            System.out.println("Director->Inserted..."+rows);
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
    public void list(){
        String SQL="SELECT * FROM DIRECTOR";
        Statement stat;
        try{
            stat=connection.createStatement();
            ResultSet rs=stat.executeQuery(SQL);
            
            while(rs.next()){
                int dirNumber=rs.getInt("DIRECTOR_NUMBER");
                String dirName=rs.getString("DIRECTOR_NAME");
                System.out.println(dirNumber+":"+dirName);
            }
            rs.close();
            stat.close();
            
            System.out.println("Director->Inserted......");
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        DirectorDAOImpl directorDAO= new DirectorDAOImpl();
        directorDAO.save(4, "Vijay");
        directorDAO.list();
    }

 

}