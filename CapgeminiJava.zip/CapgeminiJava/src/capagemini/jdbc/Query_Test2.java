package capagemini.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;


public class Query_Test2 {


    public static void main(String[] args) {
        // 1. download jdbc driver for oracle


        // 2.copy to lib folder and to add to build path....
        try {


            // 3.load the jdbc Driver..
            Class.forName("oracle.jdbc.driver.OracleDriver");


            // 4. create connection
            Connection connection = DriverManager.getConnection(
                    "jdbc:oracle:thin:@localhost:1521/xe", "INVENTORY1",
                    "INVENTORY1");


            // 5. create statement for sql query....
            Statement stat = connection.createStatement();


            // 6. execute the query
            String SQL = "INSERT INTO DIRECTOR VALUES(? , ?)";


            PreparedStatement pstat = connection.prepareStatement(SQL);
            int dirNumber = 7;
            String dirName = "Vijay1";


            pstat.setInt(1, dirNumber);
            pstat.setString(2, dirName);
            int rows = pstat.executeUpdate();
            System.out.println(rows + " Inserted...");


            // commit the transaction


            connection.setAutoCommit(false);
            connection.commit();


            // close the database resources


            pstat.close();
            connection.close();


        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e1) {
            e1.printStackTrace();
        }
    }


}
 
