package capagemini.jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;


public class Query_Test {


    public static void main(String[] args) {
        // 1.Download JDBC Driver for Oracle
        // 2.Copy to lib folder and add to build path
        try {
            // 3.Load the JDBC driver
            Class.forName("oracle.jdbc.driver.OracleDriver");
            String URL = "jdbc:oracle:thin:@localhost:1521/xe";
            String username = "INVENTORY1";
            String password = "INVENTORY1";
            
            Connection connection =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe",
                            "INVENTORY1", "INVENTORY1");
                   
                   
                    Statement stat = connection.createStatement();
                    
            //Creating static query
            String SQL="SELECT * FROM DIRECTOR";
            ResultSet rs = stat.executeQuery(SQL);
            
            //Retriving Table structure
            ResultSetMetaData rsmd = rs.getMetaData();
            int colCount = rsmd.getColumnCount();
            for(int index=1; index<=colCount; index++){
                String colName =rsmd.getColumnName(index);
                String colType = rsmd.getColumnTypeName(index);
                System.out.println(colName +":" +colType);
            }
            //Process the result
            while (rs.next()) {
                int dirNumber = rs.getInt("DIRECTOR_NUMBER");
                String dirName = rs.getString("DIRECTOR_NAME");
                        
                System.out.println(dirNumber +":" +dirName);
            }


            // 8. Close the database resources
            rs.close();
            stat.close();
            connection.close();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}