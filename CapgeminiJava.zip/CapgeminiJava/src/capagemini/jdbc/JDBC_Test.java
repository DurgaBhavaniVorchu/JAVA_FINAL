package capagemini.jdbc;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBC_Test {
	public static void main(String[] args) {
		try {
			//3. load the jdbc....
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			//4. create connection 
			Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe",
					"INVENTORY1", "INVENTORY1");
			
			//5. create statement for SQL query
			Statement stat = connection.createStatement();
			
			//6. Execute the query..
			String SQL = "SELECT * FROM CUSTOMER";
			ResultSet rs= stat.executeQuery(SQL);
			
			//7. process the result..
			while(rs.next()) {
				System.out.println(rs.getString("first_Name"));
			}
			//8. close the data base resources..
			rs.close();
			stat.close();
			connection.close();
			
		}
		catch(ClassNotFoundException e) {
			e.printStackTrace();
		}catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
}

