

class parent{
	parent()
	{
		System.out.println("Bhavani");
	}
	
	
}
class krishna extends parent{
	krishna(){
		super();
		System.out.println("krishna");

	}
}

public class ConstructorDemo {
	public static void main(String args[]){
		krishna sc = new krishna();
	}

}
