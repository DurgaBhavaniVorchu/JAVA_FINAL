
class person{
	void message(){
		System.out.println("buddy");
		
	}
}
class bhavani extends person{
	void message()
	{
		super.message();
		System.out.println("krishna");
		
        System.out.println("Sampath");
		super.message();
	}
}












public class Methodsuper {
	public static void main(String []args){
		
		bhavani sc=new bhavani();
		sc.message();
		
	}

}
