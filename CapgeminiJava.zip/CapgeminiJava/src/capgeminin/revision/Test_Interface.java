package capgeminin.revision;
interface Printer{
	public void print(Document document);
	
	}

 class HP_Printer implements Printer {
	 private static int COUNT=0;
	 @Override
	 public void print(Document document){
		 HP_Printer.COUNT+=1;
		 System.out.println(document);
	 }
	 public int getCount() {
		 return COUNT;
	 }
}

 public class Test_Interface {
	 public static void main(String args[]){
		 Word word = new Word("MS Word");
		 Excel excel = new Excel("MS Excel");
		 PowerPoint powerPoint = new PowerPoint("MS PowerPoint");
		 Printer printer = new HP_Printer();
		 HP_Printer hp_printer = new HP_Printer();
		 printer.print(word);
		 printer.print(excel);
		 printer.print(powerPoint);
		 
		 System.out.println(hp_printer.getCount());
		 
	 }
 }