package capgeminin.revision;

public class Test_Arrays {
	public static void main(String args[]) {
		//int arrays
	}
}
