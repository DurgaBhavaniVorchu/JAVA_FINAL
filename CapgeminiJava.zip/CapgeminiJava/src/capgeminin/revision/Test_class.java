package capgeminin.revision;


public class Test_class {
	public static void main(String args[]) {
		//implementing default constructor....
		Product p4 = new Product();
		p4.setProdId(1);
		p4.setName("Lap");
		p4.setCost(5.5f);
		
		Product p5 = new Product();
		p5.setProdId(2);
		p5.setName("Lapt");
		p5.setCost(6.5f);
		
		Product p6 = new Product();
		p6.setProdId(2);
		p6.setName("Lapt");
		p6.setCost(6.5f);
		
		//implementing parameterized constructor....
		Product p1 = new Product(101, "laptop", 22000.22f);
		Product p2 = new Product(102, "TV", 32000.22f);
		Product p3 = new Product(103, "washingMachine",42000.22f);
		
		//implementing of toString method...........
		System.out.println(p1.toString());
		System.out.println(p2.toString());
		System.out.println(p3.toString());
		
		System.out.println(p5.getProdId());
		System.out.println(p5.getName());
		System.out.println(p5.getCost());
		
		System.out.println(p4.getProdId());
		System.out.println(p4.getName());
		System.out.println(p4.getCost());
		
		System.out.println(p6.getProdId());
		System.out.println(p6.getName());
		System.out.println(p6.getCost());
		
		if(p5.equals(p6)){
			System.out.println("p5 equals p6");
		}
		else{
			System.out.println("p5 not equals p6");
		}
		
		//object arrays.......
		
		Product[] p7 = new Product[5];
		p7[0] = new Product(104, "bhavani", 222.22f); 
		p7[1] = new Product(105, "kalyani", 322.22f);
		p7[2] = new Product(106, "meghana", 422.22f);
		p7[3] = new Product(107, "krishna", 522.22f);
		p7[4] = new Product(108, "sampath", 622.22f);
		
/*		p7[0].setCost(222.22f);
		p7[1].setCost(322.22f);
		p7[2].setCost(422.22f);
		p7[3].setCost(522.22f);
		p7[4].setCost(6722.22f);
*/		float sum =0;
		for(int i=0 ; i<p7.length;i++){
			sum = sum+p7[i].getCost();
		}
		System.out.println("Total cost : "+sum);
	}
}

class Product {
	// fields...
	private int prodId;
	private String name;
	private float cost;

	// default contructor...
	Product() {
		super();
		setProdId(0);
		setName(null);
		setCost(0.0f);
		System.out.println("Def -> contructor....");
	}

	// Param contructor.....
	Product(int prodId, String name, float cost) {
		this.prodId = prodId;
		this.name = name;
		this.cost = cost;
		System.out.println("Parameterized->constructor....");
	}

	// getters and setters........
	public int getProdId() {
		return prodId;
	}

	public void setProdId(int prodId) {
		this.prodId = prodId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getCost() {
		return cost;
	}

	public void setCost(float cost) {
		this.cost = cost;
	}
	
	//toString method........

	@Override
	public String toString() {
		return "product[ " + "prodId:" + prodId + " name:" + name + " cost:" + cost + " ]";
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj == null){
			return false;
		}
		Product otherProduct = (Product)obj;
		if(this.prodId == otherProduct.prodId && this.name.equals(otherProduct.name) && this.cost == otherProduct.cost) {
			return true;
		}
		return false;
	}

	
}