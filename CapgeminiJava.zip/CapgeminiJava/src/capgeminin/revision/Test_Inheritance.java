package capgeminin.revision;

abstract class Document {
	String text;

	public Document() {
		super();
		text = "Document......";
		System.out.println("Document Def->Constructor...");
	}

	public Document(String text) {
		super();
		this.text = text;
		System.out.println("Document Param->Constructor...");
	}

	public abstract void open();

	public abstract void read();

	public abstract void write();

	public abstract void close();
	
	public String toString(){
		return "Text : "+text;
		
	}
	
	public boolean equals(Object obj) {
		if(obj == null)
			return false;
		Document otherDocument = (Document)obj;
		if(this.text.equals(otherDocument))
			return true;
		return false;
		
	}
}

class Word extends Document {
	public Word() {
		super("word document...");
		System.out.println("word Def->Constructor...");
	}

	public Word(String text) {
		super(text);
		System.out.println("word Param->Constructor...");
	}

	@Override
	public void open() {
		System.out.println("Word->Open...");
	}

	@Override
	public void read() {
		System.out.println("Word Read...");
	}

	@Override
	public void write() {
		System.out.println("Word Write...");
	}

	@Override
	public void close() {
		System.out.println("Word->Close...");
	}
	
	public String toString(){
		return super.toString()+"\tText : "+text;
		
	}
}

class Excel extends Document {
	Excel() {
		super("Excel document...");

		System.out.println("Excel Def->Constructor...");
	}

	Excel(String text) {
		super(text);
		System.out.println("Excel Param->Constructor...");
	}

	@Override
	public void open() {
		System.out.println("Excel Open...");
	}

	@Override
	public void read() {
		System.out.println("Excel Read...");
	}

	@Override
	public void write() {
		System.out.println("Excel Write...");
	}

	@Override
	public void close() {
		System.out.println("Excel Close...");
	}
	
	public String toString(){
		return super.toString()+"\tText : "+text;
		
	}
}

class PowerPoint extends Document {
	PowerPoint() {
		super("PowerPoint document...");
		System.out.println("PowerPoint Def->Constructor...");
	}

	PowerPoint(String text) {
		super(text);
		System.out.println("PowerPoint Param->Constructor...");
	}

	@Override
	public void open() {
		System.out.println("PowerPoint Open...");
	}

	@Override
	public void read() {
		System.out.println("PowerPoint Read...");
	}

	@Override
	public void write() {
		System.out.println("PowerPoint Write...");
	}

	@Override
	public void close() {
		System.out.println("PowerPoint Close...");
	}
	
	public String toString(){
		return super.toString()+"\tText : "+text;
		
	}
}

public class Test_Inheritance {
	public static void main(String args[]) {
		
		
		Document word = new Word();
		word = new Word("Word Document");
		word.open();
		word.read();
		word.write();
		word.close();
		System.out.println(word.toString());
		
		Document excel = new Excel();
		excel = new Excel("Excel Document");
		excel.open();
		excel.read();
		excel.write();
		excel.close();
		System.out.println(excel.toString());
		
		Document powerPoint = new PowerPoint();
		powerPoint = new PowerPoint("powerPoint Document");
		powerPoint.open();
		powerPoint.read();
		powerPoint.write();
		powerPoint.close();
		System.out.println(powerPoint.toString());
		
		
	}
}
