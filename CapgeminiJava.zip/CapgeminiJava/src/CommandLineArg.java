
public class CommandLineArg {
	public static void main(String args[])
	{
		String value1,value2;
		value1=value2=null;
		value1=args[0];
		value2=args[1];
		System.out.println("value1 : "+value1);
		System.out.println("value2 : "+value2);
		
	}
}
