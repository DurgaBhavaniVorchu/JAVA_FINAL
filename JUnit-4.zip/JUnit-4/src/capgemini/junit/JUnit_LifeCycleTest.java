package capgemini.junit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class JUnit_LifeCycleTest {

	@BeforeClass
	public static void beforeClass() {
		System.out.println("Lifecycle->beforeClass");
	}
	
	@Before
	public void before() {
		System.out.println("\tLifecycle->before");
	}

	@Test
	public void testOne() {
		System.out.println("\tLifecycle->testOne");
	}

	@Test
	public void testTwo() {
		System.out.println("\tLifecycle->testTwo");
	}

	@After
	public void after() {
		System.out.println("\tLifeCycle->after");
	}

	@AfterClass
	public static void afterClass() {
		System.out.println("LifeCycle->afterClass");
	}

}