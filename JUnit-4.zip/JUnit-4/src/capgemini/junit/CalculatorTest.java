package capgemini.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalculatorTest {
	Calculator calc = new Calculator();
	@Test
	public void testAdd() {
		
		int actual = calc.add(10, 20);
		int expected = 30;
		assertEquals(expected, actual);
		//fail("testAdd->Not yet implemented...");
	}
	
	@Test
	public void testSub(){
		
		int actual = calc.sub(10, 20);
		int expected = -10;
		assertEquals(expected, actual);
	}
	
	@Test
	public void testmul(){
		
		int actual = calc.mul(10, 20);
		int expected = 200;
		assertEquals(expected, actual);
	}
	
	@Test
	public void testDiv(){
		
		int actual = calc.div(20, 10);
		int expected = 2;
		assertEquals(expected, actual);
	}
}

