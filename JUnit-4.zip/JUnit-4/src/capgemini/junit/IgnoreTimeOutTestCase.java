package capgemini.junit;

import static org.junit.Assert.*;



import org.junit.Ignore;
import org.junit.Test;

 

public class IgnoreTimeOutTestCase {
    private static final int timeout = 0;

 

    @Ignore("Yet is implement...")
    @Test
    public void testIgnore() {
        System.out.println("testIgnore");
        fail("@Ignore method will not run by JUnit4");
    }

 

    @Test(timeout = 500)
    public void testTimeOut() {
        System.out.println("Test(timeout) can be used to enforce timeout in JUnit4");
        while (true) {
        }

 

    }
}