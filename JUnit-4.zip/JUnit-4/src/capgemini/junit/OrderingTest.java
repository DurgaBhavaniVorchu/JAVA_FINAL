package capgemini.junit;

import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.junit.FixMethodOrder;
//@FixMehodOrder(MethodSorters.NAME_ASCENDING)

 

public class OrderingTest {
    @Test
    public void testA() {
        System.out.println("first");
    }
    @Test
    public void testB() {
        System.out.println("second");
    }
    @Test
    public void testC() {
        System.out.println("third");
    }
    @Test
    public void testD() {
        System.out.println("fourth");
    }
    @Test
    public void testE() {
        System.out.println("fifth");
    }

 

}