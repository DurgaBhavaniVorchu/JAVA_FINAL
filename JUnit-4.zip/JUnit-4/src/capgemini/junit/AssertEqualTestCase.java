package capgemini.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class AssertEqualTestCase {
	private static final String JUnit4 = null;
	private Object text;

	@Test
	public void testAssertEqual() {
		String expected = "JUnit4";
		String actual = "Junit4";
		assertEquals(expected, actual);

	}

	@Test
	public void testAssertNull() {
		String Test = null;
		assertNull("the should be null", text);

	}

	@Test
	public void testAssertNotNull() {
		String Test = "testAssertNotNull";
		assertNull("the should be not null", text);

	}

	@Test
	public void testAssertSame() {
		Object junit4 = new Object();
		Object junit5 = junit4;
		assertSame(JUnit4, junit5);

	}

	@Test
	public void testAssertNotSame() {
		Object junit4 = new Object();
		Object junit5 = new Object();
		assertNotSame(JUnit4, junit5);

	}

	@Test
	public void testAssertTrue() {
		assertTrue("5 is greater than 4", 5 > 4);
	}

	@Test
	public void testAssertFalse() {
		assertFalse("5 is greater than 6", 5 > 6);
	}
}
