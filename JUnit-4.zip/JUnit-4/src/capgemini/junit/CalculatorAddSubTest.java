package capgemini.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalculatorAddSubTest {
	Calculator calc = new Calculator();
	@Test
	public void testAdd() {
		
		int actual = calc.add(10, 20);
		int expected = 30;
		assertEquals(expected, actual);
		//fail("testAdd->Not yet implemented...");
	}
	
	@Test
	public void testSub(){
		
		int actual = calc.sub(10, 20);
		int expected = -10;
		assertEquals(expected, actual);
	}
	
	
}

