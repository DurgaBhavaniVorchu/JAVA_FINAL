package capgemini.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalculatorMulDivTest {
	Calculator calc = new Calculator();
	
	@Test
	public void testmul(){
		
		int actual = calc.mul(10, 20);
		int expected = 200;
		assertEquals(expected, actual);
	}
	
	@Test
	public void testDiv(){
		
		int actual = calc.div(20, 10);
		int expected = 2;
		assertEquals(expected, actual);
	}
}

