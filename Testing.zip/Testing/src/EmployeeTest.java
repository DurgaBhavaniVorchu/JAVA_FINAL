
import static org.junit.Assert.*;

import org.junit.Test;

public class EmployeeTest {
	@Test
	public void testcalNetPay1() {
		Employee employee = new Employee(101,"sandeep",10000,5);
		double actual = employee.calNetPay();
		double expected = 10000;
		assertTrue(expected==actual);
	}
	@Test
	public void testcalNetPay2() {
		Employee employee = new Employee(101,"sandeep",10000,6);
		double actual = employee.calNetPay();
		double expected = 9400;
		assertTrue(expected==actual);
	}
}
