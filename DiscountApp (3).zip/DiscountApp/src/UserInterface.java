
import java.util.Scanner;

public class UserInterface {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int numOfProducts = sc.nextInt();
		String prod[] = new String[numOfProducts];

		for (int i = 0; i < numOfProducts; i++) {
			prod[i] = sc.next();
		}

		float disc1 = 100000.0f;
		String product1 = null;

		float disc2 = 100000.0f;
		String product2 = null;
		for (int i = 0; i < numOfProducts; i++) {
			String[] seProd = prod[i].split(",");

			float disc = (Integer.parseInt(seProd[1]) * Integer.parseInt(seProd[2])) / 100;
			System.out.println(disc);
			if (disc < disc1) {
				disc1 = disc;
				product1 = seProd[0];
			}

			else if (disc == disc1) {
				disc2 = disc;
				product2 = seProd[0];
			}
		}

		System.out.println(product1 + " " + disc1);

		if (disc2 == disc1) {
			System.out.println(product2 + " " + disc2);
		}

		sc.close();
	}

}
