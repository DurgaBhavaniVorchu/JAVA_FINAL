package com.capgemini;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.utility.DBConnection;

public class Lab11 {
	Connection connection=null;
	PreparedStatement statement=null;
	ResultSet set=null;
	boolean status=false;
	int row=-1;
	Scanner scanner=new Scanner(System.in);
	public void display() {
		try {
			connection=DBConnection.getConnection();
			statement=connection.prepareStatement("select * from lab1");
			set=statement.executeQuery();
			while(set.next())
				System.out.println(set.getInt("sno")+" "+set.getString("subject"));
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	public void delete() {
		try {
			connection=DBConnection.getConnection();
			int sno=scanner.nextInt();
			statement=connection.prepareStatement("delete from lab1 where sno=?");
			statement.setInt(1, sno);
			row=statement.executeUpdate();
			System.out.println("deleted "+row);
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	public static void main(String[] args) {
		Lab11 lab11=new Lab11();
		System.out.println("Enter your choice:");
		Scanner scanner=new Scanner(System.in);
		int choice=scanner.nextInt();
		boolean choiceFlag=false;
		do {
			switch(choice) {
			case 1: lab11.display();
			break;
			case 2: lab11.delete();
			break;
			}
		}while(!choiceFlag);
	}

}
