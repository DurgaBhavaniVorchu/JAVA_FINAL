package capgemini.banking.service;
import java.util.*;
import capgemini.banking.exception.*;
import capgemini.banking.bean.*;


public interface AccountService {
	    
	    
		public Account createAccount();
	    
		public void showBalance() throws AccountNotFoundException ;
	    
	    public void deposit() throws AccountNotFoundException ;
	    
	    public void withDraw() throws AccountNotFoundException,InsufficientBalanceException ;
	    
	    public void fundTransfer() throws AccountNotFoundException, InsufficientBalanceException ;
	    
	    public Collection<Account> getTransaction();
}
