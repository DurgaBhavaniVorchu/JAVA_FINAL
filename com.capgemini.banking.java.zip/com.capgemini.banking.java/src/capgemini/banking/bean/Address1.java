package capgemini.banking.bean;
public class Address1 {
	String door_Number;
	String street;
	String city;
	String pinCode;

	public Address1() {
		super();
		this.door_Number = null;
		this.street = null;
		this.city = null;
		this.pinCode = null;
	}

	public Address1(String door_Number, String street, String city, String pinCode) {
		super();
		this.door_Number = door_Number;
		this.street = street;
		this.city = city;
		this.pinCode = pinCode;
	}


	public String getDoor_Number() {
		return door_Number;
	}

	public void setDoor_Number(String door_Number) {
		this.door_Number = door_Number;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	@Override
	public String toString() {
		return "Address1 [door_Number=" + door_Number + ", street=" + street + ", city=" + city + ", pinCode=" + pinCode
				+ "]";
	}
	

}