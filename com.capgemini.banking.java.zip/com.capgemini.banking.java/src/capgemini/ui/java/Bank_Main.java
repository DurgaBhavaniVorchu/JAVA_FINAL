package capgemini.ui.java;

import java.util.Scanner;

import capgemini.banking.exception.AccountNotFoundException;
import capgemini.banking.exception.InsufficientBalanceException;
import capgemini.banking.service.AccountServiceImpl;

public class Bank_Main {
	public static void main(String args[]) throws Exception {
		
		AccountServiceImpl AccountServiceImplObj = new AccountServiceImpl();
		int choice = 0;
		Scanner sc = new Scanner(System.in);
		do{
			System.out.println("Welcome to HDFC Bank");
			System.out.println("1.Create Account");
			System.out.println("2.Show Balnce");
			System.out.println("3.Deposit Amount");
			System.out.println("4.With Draw Amount");
			System.out.println("5.Fund Transfer Amount");
			System.out.println("6.Print Transaction");
			System.out.println("7.Exit");
			System.out.println("Enter Choice :");
			choice = sc.nextInt();
			
			switch(choice){
			case 1:
				AccountServiceImplObj.createAccount();
				break;
			case 2:
				AccountServiceImplObj.showBalance();
				break;
			case 3:
				AccountServiceImplObj.deposit();
				break;
			case 4:
				AccountServiceImplObj.withDraw();
				break;
			case 5:
				AccountServiceImplObj.fundTransfer();
				break;
			case 6:
				System.out.println("All transactions: "+AccountServiceImplObj.getTransaction());
				break;
			
			}
		}while(choice != 8);
		
	}
	
}
