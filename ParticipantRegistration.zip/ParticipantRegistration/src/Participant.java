
public class Participant {
	//fields..........
	private String name;
	private char gender;
	private String department;
	//creating gettres and setters.........
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public char getGender() {
		return gender;
	}
	//This setGender throws GenderInvalidException....
	public void setGender(char gender) throws GenderInValidException {
		if (gender == 'M' || gender == 'F'|| gender == 'T' || gender == 'm' || gender == 'f'|| gender == 't'){
				this.gender = gender;
	}
	else{
		throw new GenderInValidException("Invalid Gender");
	}
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}	
}
