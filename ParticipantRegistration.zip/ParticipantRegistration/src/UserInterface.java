import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args)  {
		// Declare the object and initialize with  predefined standard input object
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Name");
		String name=sc.nextLine();
		System.out.println("Enter Department");
		String dept=sc.nextLine();
		System.out.println("Enter Gender");
		char gender = sc.nextLine().charAt(0);
		//creating new object for a Participant class
		Participant participant = new Participant();
		participant.setName(name);
		participant.setDepartment(dept); 
		try{
			participant.setGender(gender);
            System.out.println("Registration Successful");
        }
		// matching GenderInValidException 
        catch(GenderInValidException e){
        	// getMessage will print description of exception(here / by zero)
            System.out.println("Invalid Gender");
        }
		

	}
	
}


