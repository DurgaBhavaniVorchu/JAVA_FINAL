
public class PropertyTax {
	private int assessmentNo;
	private String propertyType;
	private int sqFeet;
	//parameterized constructor.....
	public PropertyTax(int assessmentNo, String propertyType, int sqFeet) {
		super();
		this.assessmentNo=assessmentNo;
		this.propertyType=propertyType;
		this.sqFeet=sqFeet;
	}
	//method..............
	public double calculatePropertyTax(){
		if(propertyType.equalsIgnoreCase("Commercial"))
		{
			return (sqFeet*5);
		} 
		else
			return 0.0;
	}
	
	

	
	
}
