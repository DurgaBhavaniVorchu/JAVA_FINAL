import static org.junit.Assert.assertEquals;

 

import org.junit.Test;

 

public class PropertyTaxTest {
	//testing.............
    @Test
    public void propertyTest1() {
        PropertyTax propertyTax=new PropertyTax(111,"Commercial",1000);
        int expected=5000;
        int actual=(int) Math.round(propertyTax.calculatePropertyTax());
        assertEquals(expected,actual);
    }
    @Test
    public void propertyTest2() {
        PropertyTax propertyTax=new PropertyTax(111,"Public",1000);
        int expected=0;
        int actual=(int) Math.round(propertyTax.calculatePropertyTax());
        assertEquals(expected,actual);
    }

 

}