package com.ui;
import com.utility.*;
import java.util.Scanner;

public class UserInterface {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the no of Face Creams you want to store:");
		int n = sc.nextInt();
		for(int i=1;i<=n;i++){
			System.out.println("Enter the Key"+i);
			int serialNumber = sc.nextInt();
			System.out.println("Enter the value"+i);
			String productName = sc.next();
			Shop shop = new Shop();
			shop.addProductDetails(serialNumber, productName);
		}
		System.out.println("Enter the product type to be searched");
		String  productNames = sc.next();
		//Fill the UI code
		

	}

}
