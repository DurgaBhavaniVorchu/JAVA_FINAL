import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args)  {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Name");
		String name=sc.nextLine();
		System.out.println("Enter Department");
		String dept=sc.nextLine();
		System.out.println("Enter Gender");
		char gender = sc.nextLine().charAt(0);

		Participant participant = new Participant();
		participant.setName(name);
		participant.setDepartment(dept);
		try{
			participant.setGender(gender);
            System.out.println("Registration Successful");
        }
        catch(GenderInValidException e){
            System.out.println("Invalid Gender");
        }
		// fill the code

	}
	
}


