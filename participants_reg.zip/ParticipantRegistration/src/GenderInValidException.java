public class GenderInValidException extends Exception {
    public GenderInValidException(){
       
    }
    public GenderInValidException(String message){
        super(message);
    }
}
 