import java.util.ArrayList;
import java.util.Scanner;

public class UserInterface {
	//main method...........
	public static void main(String a[]) {
		// Declare the object and initialize with  predefined standard input object
		Scanner sc = new Scanner(System.in);
		int noOfEmployees = sc.nextInt();
		String employees[] = new String[noOfEmployees];
		for (int i = 0; i < noOfEmployees; i++) {
			employees[i] = sc.next();
		}
		//declaring ArrayList.........
		ArrayList<String> list1 = new ArrayList<String>();
		ArrayList<String> list2 = new ArrayList<String>();
		// Appending the new element at the end of the noOfEmployees variable 
		for (int i = 0; i < noOfEmployees; i++) {
			String s[] = new String[3];
			s = employees[i].split(",");
			s[1] = s[1].replace(":", "");
			s[2] = s[2].replace(":", "");
			int x = Integer.parseInt(s[1]);
			int y = Integer.parseInt(s[2]);
			if (x >= y) {
				list1.add(s[0]);
			} else
				list2.add(s[0]);
		}
		if (!list1.isEmpty()) {
			for (String string : list1) {
				System.out.print(string + " ");
			}
			// Printing elements 
			System.out.println("are eligible for Bonus");
		} else {
			for (String string : list2) {
				// Displaying ArrayList
				System.out.print(string + " ");
			}
			// Printing elements 
			System.out.println("are not eligible for Bonus");
		}
		//scanner closing
		sc.close();
	}

}
