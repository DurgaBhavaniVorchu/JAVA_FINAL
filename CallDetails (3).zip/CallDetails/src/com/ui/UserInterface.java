package com.ui;

import java.util.Scanner;

import com.bean.Call;
import com.utility.CallHistory;

public class UserInterface {
	
	public static void main(String a[]){
		Call call = null;
		CallHistory callHistory =null;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of call details");
		int num = sc.nextInt();
		String[] str = null;
		for(int i =0 ;i<num;i++){
			 str[i] = sc.next();
			 call.parseData(str[i]);
		}
		System.out.println("Enter the called number");
		long searchNum = sc.nextLong();
		System.out.println(callHistory.findTotalDuration(searchNum));
	}

}
